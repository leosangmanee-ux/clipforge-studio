import type { Project } from './types';

const DB = 'clipforge', VER = 1;
let dbp: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  return (dbp ??= new Promise((res, rej) => {
    const r = indexedDB.open(DB, VER);
    r.onupgradeneeded = () => {
      const d = r.result;
      d.createObjectStore('projects', { keyPath: 'id' });
      d.createObjectStore('media', { keyPath: 'id' }).createIndex('projectId', 'projectId');
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  }));
}
async function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T> {
  const d = await open();
  return new Promise((res, rej) => {
    const t = d.transaction(store, mode);
    const rq = fn(t.objectStore(store));
    t.oncomplete = () => res(rq ? (rq as IDBRequest<T>).result : (undefined as T));
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error);
  });
}

export interface ProjectRow { id: string; name: string; updated: number; data: string }
export const putProject = (p: Project) =>
  tx('projects', 'readwrite', (s) => s.put({ id: p.id, name: p.name, updated: p.updated, data: JSON.stringify(p) } as ProjectRow));
export const getProject = (id: string) => tx<ProjectRow | undefined>('projects', 'readonly', (s) => s.get(id));
export const listProjects = () => tx<ProjectRow[]>('projects', 'readonly', (s) => s.getAll());
export async function deleteProject(id: string) {
  await tx('projects', 'readwrite', (s) => s.delete(id));
  const d = await open();
  await new Promise<void>((res, rej) => {
    const t = d.transaction('media', 'readwrite');
    const idx = t.objectStore('media').index('projectId');
    idx.openKeyCursor(IDBKeyRange.only(id)).onsuccess = (e) => {
      const c = (e.target as IDBRequest<IDBCursor | null>).result;
      if (c) { t.objectStore('media').delete(c.primaryKey); c.continue(); }
    };
    t.oncomplete = () => res(); t.onerror = () => rej(t.error);
  });
}
export const putMedia = (id: string, projectId: string, blob: Blob) =>
  tx('media', 'readwrite', (s) => s.put({ id, projectId, blob }));
export const getMedia = (id: string) =>
  tx<{ id: string; blob: Blob } | undefined>('media', 'readonly', (s) => s.get(id));
export const deleteMedia = (id: string) => tx('media', 'readwrite', (s) => s.delete(id));
