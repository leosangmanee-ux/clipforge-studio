export type Aspect = '16:9' | '9:16' | '1:1';
export type ClipType = 'video' | 'audio' | 'image' | 'text';
export type Dir = 'left' | 'right' | 'up' | 'down';

export interface MediaItem {
  id: string; name: string; kind: 'video' | 'audio' | 'image';
  duration: number; width: number; height: number; hasAudio: boolean;
}
export interface Anim { type: string; dur: number; delay: number; dir: Dir }
export interface TextProps {
  text: string; font: string; size: number; color: string;
  align: 'left' | 'center' | 'right'; bold: boolean; italic: boolean;
  outlineColor: string; outlineW: number;
  shadow: boolean; shadowColor: string; shadowBlur: number; shadowX: number; shadowY: number;
  gradient: boolean; color2: string; gradAngle: number;
  letterSpacing: number; lineHeight: number;
  x: number; y: number; rotation: number; boxW: number;
  animIn: Anim; animOut: Anim;
}
export interface EffectInst { id: string; type: string; enabled: boolean; params: Record<string, number> }
export interface Crop { l: number; t: number; r: number; b: number }
export interface Clip {
  id: string; track: string; type: ClipType; mediaId?: string; label: string;
  start: number; dur: number; in: number; speed: number;
  volume: number; fadeIn: number; fadeOut: number; muted: boolean;
  x: number; y: number; scale: number; rotate: number; opacity: number;
  fit: 'contain' | 'cover'; crop: Crop;
  text?: TextProps; effects: EffectInst[];
}
export interface Cue { id: string; start: number; end: number; text: string }
export interface SubStyle {
  font: string; size: number; color: string; outlineColor: string; outlineW: number;
  bold: boolean; bg: boolean; bgColor: string; bgOpacity: number; y: number;
}
export interface Track { id: string; name: string; kind: 'video' | 'text' | 'audio'; z: number }
export interface Project {
  id: string; name: string; aspect: Aspect; fps: number;
  tracks: Track[]; clips: Clip[]; cues: Cue[]; subStyle: SubStyle; media: MediaItem[]; updated: number;
}
