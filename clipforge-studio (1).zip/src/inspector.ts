import type { Clip, Cue, TextProps } from './types';
import { findFree, store } from './store';
import { EFFECTS } from './render/effects';
import { FONTS } from './fonts';
import { newEffect, setSpeed } from './clips';
import { parseSRT, serializeSRT } from './subtitles';
import { download, h, toast, uid } from './util';
import type { Player } from './player';

type Tab = 'clip' | 'text' | 'fx' | 'subs' | 'project';
const TABS: [Tab, string][] = [['clip', 'Clip'], ['text', 'Text'], ['fx', 'Effects'], ['subs', 'Subtitles'], ['project', 'Project']];

const row = (label: string, ...els: Node[]) => h('div', { class: 'row' }, h('span', { class: 'rl' }, label), h('div', { class: 'rc' }, ...els));
const section = (t: string) => h('div', { class: 'sec' }, t);

function slider(label: string, min: number, max: number, step: number, get: () => number, set: (v: number) => void, opts: { live?: boolean; id?: string } = {}) {
  const live = opts.live !== false;
  const out = h('span', { class: 'val' }, String(+get().toFixed(3)));
  const inp = h('input', { type: 'range', min, max, step, value: get(), id: opts.id });
  inp.addEventListener('input', () => { out.textContent = String(+Number(inp.value).toFixed(3)); if (live) set(Number(inp.value)); });
  if (!live) inp.addEventListener('change', () => set(Number(inp.value)));
  return row(label, inp, out);
}
function num(label: string, get: () => number, set: (v: number) => void, step = 0.1, id?: string) {
  const inp = h('input', { type: 'number', step, value: +get().toFixed(3), class: 'num', id });
  inp.addEventListener('change', () => set(Number(inp.value)));
  return row(label, inp);
}
function select(label: string, opts: [string, string][], get: () => string, set: (v: string) => void, id?: string) {
  const s = h('select', { id }, ...opts.map(([v, l]) => h('option', { value: v, selected: v === get() }, l)));
  s.addEventListener('change', () => set(s.value)); return row(label, s);
}
function check(label: string, get: () => boolean, set: (v: boolean) => void, id?: string) {
  const c = h('input', { type: 'checkbox', checked: get(), id }); c.addEventListener('change', () => set(c.checked)); return row(label, c);
}
function color(label: string, get: () => string, set: (v: string) => void) {
  const c = h('input', { type: 'color', value: get().slice(0, 7) }); c.addEventListener('input', () => set(c.value)); return row(label, c);
}

export class Inspector {
  tab: Tab = 'clip'; private lastSel = '';
  constructor(public root: HTMLElement, private player: Player) {
    store.on((src) => {
      if (src === 'inspector' || src === 'drag') return;
      if (src === 'select') {
        const c = store.selClip, key = store.sel.join(',') + store.selCue;
        if (key !== this.lastSel) {
          this.lastSel = key;
          if (c?.type === 'text') this.tab = 'text'; else if (c && this.tab === 'text') this.tab = 'clip'; else if (store.selCue) this.tab = 'subs';
        }
      }
      this.render();
    });
    this.render();
  }

  /** Mutate the selected clip (live – no inspector rebuild while dragging a slider). */
  private live(id: string, key: string, fn: (c: Clip) => void) {
    store.update((p) => { const c = p.clips.find((x) => x.id === id); if (c) fn(c); }, { key: `${id}:${key}`, src: 'inspector' });
  }
  private commit(id: string, fn: (c: Clip) => void) {
    store.update((p) => { const c = p.clips.find((x) => x.id === id); if (c) fn(c); }, { src: 'ui' });
  }

  render() {
    const keepScroll = this.root.querySelector('.insp-body')?.scrollTop ?? 0;
    const tabs = h('div', { class: 'tabs' }, ...TABS.map(([id, l]) => h('button', { class: `tab ${this.tab === id ? 'on' : ''}`, id: `tab-${id}`, onclick: () => { this.tab = id; this.render(); } }, l)));
    const body = h('div', { class: 'insp-body' });
    const c = store.selClip;
    if (this.tab === 'clip') this.clipTab(body, c);
    else if (this.tab === 'text') this.textTab(body, c);
    else if (this.tab === 'fx') this.fxTab(body, c);
    else if (this.tab === 'subs') this.subsTab(body);
    else this.projectTab(body);
    this.root.replaceChildren(tabs, body); body.scrollTop = keepScroll;
  }

  private clipTab(b: HTMLElement, c?: Clip) {
    if (!c) { b.append(h('p', { class: 'hint' }, store.sel.length > 1 ? `${store.sel.length} clips selected. Use Combine in the timeline toolbar.` : 'Select a clip in the timeline to edit its timing, speed, audio, crop and rotation.')); return; }
    const id = c.id, media = c.mediaId ? store.p.media.find((m) => m.id === c.mediaId) : undefined;
    b.append(section(`${c.type.toUpperCase()} · ${c.label || 'clip'}`));
    b.append(num('Start (s)', () => c.start, (v) => {
      const s = findFree(store.p, c.track, Math.max(0, v), c.dur, c.id);
      if (s === null || Math.abs(s - Math.max(0, v)) > 1e-6) toast('That position overlaps another clip on this track.', 'error');
      else this.commit(id, (k) => (k.start = s));
      this.render();
    }, 0.1, 'f-start'));
    b.append(num('Duration (s)', () => c.dur, (v) => {
      let d = Math.max(0.1, v); if (media && c.type !== 'image') d = Math.min(d, (media.duration - c.in) / c.speed);
      const next = Math.min(Infinity, ...store.p.clips.filter((k) => k.track === c.track && k.id !== c.id && k.start >= c.start + 1e-6).map((k) => k.start));
      if (c.start + d > next + 1e-6) { d = next - c.start; toast('Trimmed to the next clip on the track.', 'info'); }
      this.commit(id, (k) => (k.dur = d));
    }, 0.1, 'f-dur'));
    if (c.type === 'video' || c.type === 'audio') {
      b.append(slider('Speed', 0.25, 4, 0.05, () => c.speed, (v) => this.commit(id, (k) => setSpeed(k, v)), { live: false, id: 'f-speed' }));
      b.append(section('Audio'));
      if (c.type === 'video' && !media?.hasAudio) b.append(h('p', { class: 'hint' }, 'This video has no audio track.'));
      b.append(slider('Volume', 0, 2, 0.01, () => c.volume, (v) => this.live(id, 'vol', (k) => (k.volume = v)), { id: 'f-volume' }));
      b.append(slider('Fade in (s)', 0, 5, 0.1, () => c.fadeIn, (v) => this.live(id, 'fi', (k) => (k.fadeIn = v)), { id: 'f-fadein' }));
      b.append(slider('Fade out (s)', 0, 5, 0.1, () => c.fadeOut, (v) => this.live(id, 'fo', (k) => (k.fadeOut = v)), { id: 'f-fadeout' }));
      b.append(check('Mute', () => c.muted, (v) => this.commit(id, (k) => (k.muted = v))));
    }
    b.append(section('Appearance'));
    b.append(slider('Opacity', 0, 1, 0.01, () => c.opacity, (v) => this.live(id, 'op', (k) => (k.opacity = v))));
    if (c.type === 'video' || c.type === 'image') {
      b.append(select('Fit', [['contain', 'Contain (letterbox)'], ['cover', 'Cover (crop to fill)']], () => c.fit, (v) => this.commit(id, (k) => (k.fit = v as any)), 'f-fit'));
      b.append(slider('Scale', 0.1, 4, 0.01, () => c.scale, (v) => this.live(id, 'sc', (k) => (k.scale = v)), { id: 'f-scale' }));
      b.append(slider('Position X', -1, 1, 0.01, () => c.x, (v) => this.live(id, 'x', (k) => (k.x = v))));
      b.append(slider('Position Y', -1, 1, 0.01, () => c.y, (v) => this.live(id, 'y', (k) => (k.y = v))));
      b.append(slider('Rotate (°)', -180, 180, 1, () => c.rotate, (v) => this.live(id, 'rot', (k) => (k.rotate = v)), { id: 'f-rotate' }));
      b.append(row('', h('button', { class: 'btn sm', id: 'btn-rot90', onclick: () => this.commit(id, (k) => { k.rotate = ((((k.rotate + 90 + 180) % 360) + 360) % 360) - 180; }) }, '⟳ Rotate 90°')));
      b.append(section('Crop'));
      for (const [k, l] of [['l', 'Left'], ['t', 'Top'], ['r', 'Right'], ['b', 'Bottom']] as const)
        b.append(slider(l, 0, 0.9, 0.005, () => c.crop[k], (v) => this.live(id, 'cr' + k, (cl) => (cl.crop[k] = v)), { id: `f-crop-${k}` }));
    }
  }

  private textTab(b: HTMLElement, c?: Clip) {
    if (!c || c.type !== 'text' || !c.text) { b.append(h('p', { class: 'hint' }, 'Select a text clip, or press “＋ Text” in the timeline toolbar to add one.')); return; }
    const id = c.id, T = c.text;
    const set = (key: string, fn: (t: TextProps) => void, fonts = false) => { this.live(id, 't' + key, (k) => fn(k.text!)); if (fonts) this.player.fontsThenRender(); };
    const ta = h('textarea', { rows: 3, id: 'f-text', class: 'ta', value: T.text, placeholder: 'พิมพ์ข้อความ / Type text' });
    ta.addEventListener('input', () => { set('text', (t) => (t.text = ta.value), true); });
    b.append(section('Text'), ta);
    b.append(select('Font', FONTS.map((f) => [f.name, f.label]), () => T.font, (v) => { set('font', (t) => (t.font = v), true); }, 'f-font'));
    b.append(slider('Size', 16, 320, 1, () => T.size, (v) => set('size', (t) => (t.size = v)), { id: 'f-size' }));
    b.append(color('Color', () => T.color, (v) => set('col', (t) => (t.color = v))));
    b.append(row('Style',
      h('button', { class: `btn sm ${T.bold ? 'on' : ''}`, id: 'f-bold', onclick: () => { this.commit(id, (k) => (k.text!.bold = !k.text!.bold)); this.player.fontsThenRender(); } }, 'B'),
      h('button', { class: `btn sm ${T.italic ? 'on' : ''}`, id: 'f-italic', onclick: () => this.commit(id, (k) => (k.text!.italic = !k.text!.italic)) }, 'I'),
      ...(['left', 'center', 'right'] as const).map((a) => h('button', { class: `btn sm ${T.align === a ? 'on' : ''}`, onclick: () => this.commit(id, (k) => (k.text!.align = a)) }, a === 'left' ? '⯇' : a === 'right' ? '⯈' : '≡'))));
    b.append(check('Gradient fill', () => T.gradient, (v) => this.commit(id, (k) => (k.text!.gradient = v)), 'f-grad'));
    if (T.gradient) {
      b.append(color('Gradient end', () => T.color2, (v) => set('c2', (t) => (t.color2 = v))));
      b.append(slider('Gradient angle', 0, 360, 1, () => T.gradAngle, (v) => set('ga', (t) => (t.gradAngle = v))));
    }
    b.append(section('Outline & shadow'));
    b.append(color('Outline color', () => T.outlineColor, (v) => set('oc', (t) => (t.outlineColor = v))));
    b.append(slider('Outline width', 0, 24, 0.5, () => T.outlineW, (v) => set('ow', (t) => (t.outlineW = v)), { id: 'f-outline' }));
    b.append(check('Shadow', () => T.shadow, (v) => this.commit(id, (k) => (k.text!.shadow = v)), 'f-shadow'));
    if (T.shadow) {
      b.append(color('Shadow color', () => T.shadowColor, (v) => set('sc', (t) => (t.shadowColor = v))));
      b.append(slider('Shadow blur', 0, 40, 1, () => T.shadowBlur, (v) => set('sb', (t) => (t.shadowBlur = v))));
      b.append(slider('Shadow X', -30, 30, 1, () => T.shadowX, (v) => set('sx', (t) => (t.shadowX = v))));
      b.append(slider('Shadow Y', -30, 30, 1, () => T.shadowY, (v) => set('sy', (t) => (t.shadowY = v))));
    }
    b.append(section('Layout'));
    b.append(slider('Letter spacing', -10, 60, 0.5, () => T.letterSpacing, (v) => set('ls', (t) => (t.letterSpacing = v)), { id: 'f-ls' }));
    b.append(slider('Line spacing', 0.8, 2.5, 0.05, () => T.lineHeight, (v) => set('lh', (t) => (t.lineHeight = v))));
    b.append(slider('Position X', 0, 1, 0.005, () => T.x, (v) => set('x', (t) => (t.x = v)), { id: 'f-tx' }));
    b.append(slider('Position Y', 0, 1, 0.005, () => T.y, (v) => set('y', (t) => (t.y = v)), { id: 'f-ty' }));
    b.append(slider('Rotation (°)', -180, 180, 1, () => T.rotation, (v) => set('r', (t) => (t.rotation = v))));
    b.append(slider('Box width', 0.2, 1, 0.01, () => T.boxW, (v) => set('bw', (t) => (t.boxW = v))));
    const IN: [string, string][] = [['none', 'None'], ['fade', 'Fade In'], ['slide', 'Slide In'], ['zoom', 'Zoom In'], ['typewriter', 'Typewriter'], ['bounce', 'Bounce'], ['glitch', 'Glitch'], ['kinetic', 'Kinetic']];
    const OUT: [string, string][] = [['none', 'None'], ['fade', 'Fade Out'], ['slide', 'Slide Out'], ['zoom', 'Zoom Out']];
    const DIRS: [string, string][] = [['left', 'Left'], ['right', 'Right'], ['up', 'Up'], ['down', 'Down']];
    b.append(section('Animation in'));
    b.append(select('Preset', IN, () => T.animIn.type, (v) => this.commit(id, (k) => (k.text!.animIn.type = v)), 'f-anim-in'));
    b.append(slider('Duration (s)', 0.1, 3, 0.05, () => T.animIn.dur, (v) => set('aid', (t) => (t.animIn.dur = v)), { id: 'f-anim-in-dur' }));
    b.append(slider('Delay (s)', 0, 3, 0.05, () => T.animIn.delay, (v) => set('aiy', (t) => (t.animIn.delay = v))));
    b.append(select('Direction', DIRS, () => T.animIn.dir, (v) => this.commit(id, (k) => (k.text!.animIn.dir = v as any))));
    b.append(section('Animation out'));
    b.append(select('Preset', OUT, () => T.animOut.type, (v) => this.commit(id, (k) => (k.text!.animOut.type = v)), 'f-anim-out'));
    b.append(slider('Duration (s)', 0.1, 3, 0.05, () => T.animOut.dur, (v) => set('aod', (t) => (t.animOut.dur = v))));
    b.append(select('Direction', DIRS, () => T.animOut.dir, (v) => this.commit(id, (k) => (k.text!.animOut.dir = v as any))));
  }

  private fxTab(b: HTMLElement, c?: Clip) {
    if (!c || c.type === 'audio') { b.append(h('p', { class: 'hint' }, 'Select a video, image or text clip to add effects.')); return; }
    const id = c.id;
    const sel = h('select', { id: 'fx-add-type' }, ...Object.entries(EFFECTS).map(([k, v]) => h('option', { value: k }, v.label)));
    b.append(row('Add effect', sel, h('button', { class: 'btn sm primary', id: 'fx-add', onclick: () => this.commit(id, (k) => k.effects.push(newEffect(sel.value))) }, '＋ Add')));
    if (!c.effects.length) b.append(h('p', { class: 'hint' }, 'No effects yet. Effects stack top-to-bottom and appear live in the preview and in the exported MP4.'));
    c.effects.forEach((e) => {
      const def = EFFECTS[e.type];
      const card = h('div', { class: 'fxcard', 'data-fx': e.type },
        h('div', { class: 'fxhead' },
          h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: e.enabled, onchange: (ev: Event) => this.commit(id, (k) => (k.effects.find((x) => x.id === e.id)!.enabled = (ev.target as HTMLInputElement).checked)) }), ` ${def.label}`),
          h('button', { class: 'btn sm', title: 'Remove', onclick: () => this.commit(id, (k) => (k.effects = k.effects.filter((x) => x.id !== e.id))) }, '✕')));
      for (const pd of def.params)
        card.append(slider(pd.label, pd.min, pd.max, pd.step, () => e.params[pd.key], (v) => this.live(id, `fx${e.id}${pd.key}`, (k) => (k.effects.find((x) => x.id === e.id)!.params[pd.key] = v)), { id: `fx-${e.type}-${pd.key}` }));
      b.append(card);
    });
  }

  private subsTab(b: HTMLElement) {
    const p = store.p, S = p.subStyle;
    const file = h('input', { type: 'file', accept: '.srt,.txt,text/plain', hidden: true, id: 'srt-input' });
    file.addEventListener('change', async () => {
      const f = file.files?.[0]; if (!f) return;
      const cues = parseSRT(await f.text());
      if (!cues.length) { toast('No cues found. Is this a valid .srt file?', 'error'); return; }
      store.update((pp) => pp.cues.push(...cues)); toast(`Imported ${cues.length} cues.`, 'ok'); file.value = '';
    });
    b.append(file, h('div', { class: 'btnrow' },
      h('button', { class: 'btn sm primary', id: 'cue-add', onclick: () => {
        const t = this.player.t, cue: Cue = { id: uid(), start: t, end: t + 2, text: 'ข้อความคำบรรยาย Subtitle' };
        store.update((pp) => pp.cues.push(cue)); store.selCue = cue.id; this.render();
      } }, '＋ Cue at playhead'),
      h('button', { class: 'btn sm', id: 'srt-import', onclick: () => file.click() }, '⇪ Import SRT'),
      h('button', { class: 'btn sm', id: 'srt-export', onclick: () => p.cues.length ? download(new Blob([serializeSRT(p.cues)], { type: 'text/plain;charset=utf-8' }), `${p.name || 'subtitles'}.srt`) : toast('No cues to export.', 'info') }, '⇩ Export SRT'),
      h('button', { class: 'btn sm', onclick: () => { if (p.cues.length) store.update((pp) => (pp.cues = [])); } }, 'Clear')));
    b.append(section('Style'));
    const ss = (key: string, fn: (s: typeof S) => void, fonts = false) => { store.update((pp) => fn(pp.subStyle), { key: 'sub' + key, src: 'inspector' }); if (fonts) this.player.fontsThenRender(); };
    b.append(select('Font', FONTS.map((f) => [f.name, f.label]), () => S.font, (v) => ss('font', (s) => (s.font = v), true), 'sub-font'));
    b.append(slider('Size', 16, 120, 1, () => S.size, (v) => ss('sz', (s) => (s.size = v)), { id: 'sub-size' }));
    b.append(color('Color', () => S.color, (v) => ss('c', (s) => (s.color = v))));
    b.append(color('Outline', () => S.outlineColor, (v) => ss('oc', (s) => (s.outlineColor = v))));
    b.append(slider('Outline width', 0, 12, 0.5, () => S.outlineW, (v) => ss('ow', (s) => (s.outlineW = v))));
    b.append(check('Bold', () => S.bold, (v) => { store.update((pp) => (pp.subStyle.bold = v)); this.player.fontsThenRender(); }));
    b.append(check('Background box', () => S.bg, (v) => store.update((pp) => (pp.subStyle.bg = v))));
    b.append(slider('Box opacity', 0, 1, 0.05, () => S.bgOpacity, (v) => ss('bo', (s) => (s.bgOpacity = v))));
    b.append(slider('Vertical position', 0.1, 0.98, 0.01, () => S.y, (v) => ss('y', (s) => (s.y = v))));
    b.append(section(`Cues (${p.cues.length})`));
    [...p.cues].sort((a, c) => a.start - c.start).forEach((cue) => {
      const cm = (fn: (c: Cue) => void, src = 'ui', key?: string) => store.update((pp) => { const k = pp.cues.find((x) => x.id === cue.id); if (k) fn(k); }, { src, key });
      const t = h('textarea', { rows: 2, class: 'ta', value: cue.text });
      t.addEventListener('input', () => cm((k) => (k.text = t.value), 'inspector', 'cue' + cue.id));
      t.addEventListener('focus', () => { this.player.seek(cue.start + 0.01); });
      const sIn = h('input', { type: 'number', step: 0.05, class: 'num', value: +cue.start.toFixed(3) }), eIn = h('input', { type: 'number', step: 0.05, class: 'num', value: +cue.end.toFixed(3) });
      sIn.addEventListener('change', () => cm((k) => { k.start = Math.max(0, Math.min(Number(sIn.value), k.end - 0.05)); }));
      eIn.addEventListener('change', () => cm((k) => { k.end = Math.max(k.start + 0.05, Number(eIn.value)); }));
      b.append(h('div', { class: `cuerow ${store.selCue === cue.id ? 'sel' : ''}`, 'data-cue': cue.id },
        h('div', { class: 'cuetimes' }, sIn, '→', eIn,
          h('button', { class: 'btn sm', title: 'Set start to playhead', onclick: () => cm((k) => (k.start = Math.min(this.player.t, k.end - 0.05))) }, '⇤'),
          h('button', { class: 'btn sm', title: 'Set end to playhead', onclick: () => cm((k) => (k.end = Math.max(this.player.t, k.start + 0.05))) }, '⇥'),
          h('button', { class: 'btn sm', title: 'Delete cue', onclick: () => store.update((pp) => (pp.cues = pp.cues.filter((x) => x.id !== cue.id))) }, '✕')), t));
    });
  }

  private projectTab(b: HTMLElement) {
    const p = store.p;
    const name = h('input', { type: 'text', value: p.name, id: 'proj-name', class: 'txt' });
    name.addEventListener('input', () => store.update((pp) => (pp.name = name.value), { key: 'pname', src: 'inspector' }));
    b.append(section('Project'), row('Name', name));
    b.append(select('Aspect ratio', [['16:9', '16:9 landscape'], ['9:16', '9:16 vertical'], ['1:1', '1:1 square']], () => p.aspect, (v) => { store.update((pp) => (pp.aspect = v as any)); }, 'proj-aspect'));
    b.append(h('p', { class: 'hint' }, 'Clips use “Fit: contain” (letterbox) or “cover” (crop) to adapt to the chosen aspect. Export resolution and FPS are chosen in the Export dialog.'));
    b.append(h('div', { class: 'btnrow' }, h('button', { class: 'btn primary', id: 'btn-export-2', onclick: () => document.getElementById('btn-export')!.click() }, '⬇ Export MP4…')));
  }
}
