import type { EffectInst } from '../types';
import { clamp, mulberry32 } from '../util';

export interface ParamDef { key: string; label: string; min: number; max: number; step: number; def: number }
export const EFFECTS: Record<string, { label: string; params: ParamDef[] }> = {
  brightness: { label: 'Brightness', params: [{ key: 'amount', label: 'Amount', min: -1, max: 1, step: 0.01, def: 0.2 }] },
  contrast: { label: 'Contrast', params: [{ key: 'amount', label: 'Amount', min: -1, max: 1, step: 0.01, def: 0.3 }] },
  saturation: { label: 'Saturation', params: [{ key: 'amount', label: 'Amount', min: -1, max: 2, step: 0.01, def: 0.5 }] },
  exposure: { label: 'Exposure', params: [{ key: 'ev', label: 'EV', min: -2, max: 2, step: 0.05, def: 0.5 }] },
  blur: { label: 'Blur', params: [{ key: 'radius', label: 'Radius', min: 0, max: 40, step: 0.5, def: 8 }] },
  motionblur: { label: 'Motion Blur', params: [
    { key: 'amount', label: 'Amount', min: 0, max: 1, step: 0.01, def: 0.5 }, { key: 'angle', label: 'Angle', min: 0, max: 360, step: 1, def: 0 }] },
  rgbsplit: { label: 'RGB Split', params: [
    { key: 'amount', label: 'Amount', min: 0, max: 40, step: 0.5, def: 8 }, { key: 'angle', label: 'Angle', min: 0, max: 360, step: 1, def: 0 }] },
  glitch: { label: 'Glitch', params: [
    { key: 'intensity', label: 'Intensity', min: 0, max: 1, step: 0.01, def: 0.6 }, { key: 'rate', label: 'Bursts / sec', min: 1, max: 20, step: 1, def: 8 }] },
  shake: { label: 'Shake', params: [
    { key: 'intensity', label: 'Intensity', min: 0, max: 1, step: 0.01, def: 0.5 }, { key: 'speed', label: 'Speed', min: 0.2, max: 4, step: 0.1, def: 1.5 }] },
  flash: { label: 'Flash', params: [
    { key: 'intensity', label: 'Intensity', min: 0, max: 1, step: 0.01, def: 0.8 }, { key: 'rate', label: 'Flashes / sec', min: 0.25, max: 8, step: 0.25, def: 1 }] },
  glow: { label: 'Glow', params: [
    { key: 'amount', label: 'Amount', min: 0, max: 1, step: 0.01, def: 0.6 }, { key: 'radius', label: 'Radius', min: 1, max: 60, step: 1, def: 18 }] },
  vhs: { label: 'VHS', params: [{ key: 'amount', label: 'Amount', min: 0, max: 1, step: 0.01, def: 0.7 }] },
  grain: { label: 'Film Grain', params: [{ key: 'amount', label: 'Amount', min: 0, max: 1, step: 0.01, def: 0.4 }] },
  colorgrade: { label: 'Color Grading', params: [
    { key: 'temp', label: 'Temperature', min: -1, max: 1, step: 0.01, def: 0.3 }, { key: 'tint', label: 'Tint', min: -1, max: 1, step: 0.01, def: 0 },
    { key: 'fade', label: 'Fade', min: 0, max: 1, step: 0.01, def: 0.2 }, { key: 'vignette', label: 'Vignette', min: 0, max: 1, step: 0.01, def: 0.4 }] },
};
export const defaultParams = (type: string) => Object.fromEntries(EFFECTS[type].params.map((p) => [p.key, p.def]));

type Cv = HTMLCanvasElement;
const ctxOf = (c: Cv) => c.getContext('2d', { willReadFrequently: true })!;

export function makeLayer(w: number, h: number): Cv {
  const c = document.createElement('canvas'); c.width = w; c.height = h; return c;
}
function clear(c: Cv) { const x = ctxOf(c); x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.globalCompositeOperation = 'source-over'; x.filter = 'none'; x.clearRect(0, 0, c.width, c.height); return x; }
function copy(dst: Cv, src: Cv, filter = 'none') { const x = clear(dst); x.filter = filter; x.drawImage(src, 0, 0); x.filter = 'none'; return x; }
function maskTo(dst: Cv, src: Cv) { const x = ctxOf(dst); x.save(); x.globalCompositeOperation = 'destination-in'; x.drawImage(src, 0, 0); x.restore(); }

function rgbSplitInPlace(c: Cv, dx: number, dy: number) {
  const w = c.width, h = c.height, x = ctxOf(c), s = x.getImageData(0, 0, w, h), o = x.createImageData(w, h);
  const sd = s.data, od = o.data, ox = Math.round(dx), oy = Math.round(dy);
  for (let y = 0; y < h; y++) {
    const yr = clamp(y - oy, 0, h - 1), yb = clamp(y + oy, 0, h - 1);
    for (let xx = 0; xx < w; xx++) {
      const i = (y * w + xx) * 4, ir = (yr * w + clamp(xx - ox, 0, w - 1)) * 4, ib = (yb * w + clamp(xx + ox, 0, w - 1)) * 4;
      od[i] = sd[ir]; od[i + 1] = sd[i + 1]; od[i + 2] = sd[ib + 2];
      od[i + 3] = Math.max(sd[ir + 3], sd[i + 3], sd[ib + 3]);
    }
  }
  x.putImageData(o, 0, 0);
}

const noiseTiles: Cv[] = [];
function noiseTile(k: number) {
  if (!noiseTiles[k]) {
    const c = document.createElement('canvas'); c.width = c.height = 256;
    const x = c.getContext('2d')!, id = x.createImageData(256, 256), r = mulberry32(1000 + k);
    for (let i = 0; i < id.data.length; i += 4) { const v = 128 + (r() - 0.5) * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; }
    x.putImageData(id, 0, 0); noiseTiles[k] = c;
  }
  return noiseTiles[k];
}
function addGrain(dst: Cv, src: Cv, amount: number, fi: number, S: number) {
  const x = ctxOf(dst), r = mulberry32(fi * 7919 + 13);
  x.save(); x.globalCompositeOperation = 'overlay'; x.globalAlpha = clamp(amount, 0, 1) * 0.7;
  const ox = Math.floor(r() * 256), oy = Math.floor(r() * 256), pat = x.createPattern(noiseTile(fi % 6), 'repeat')!;
  x.translate(-ox, -oy); x.scale(Math.max(1, S), Math.max(1, S)); x.fillStyle = pat; x.fillRect(0, 0, (dst.width + 512) / Math.max(1, S), (dst.height + 512) / Math.max(1, S));
  x.restore(); maskTo(dst, src);
}

export interface FxCtx { lt: number; fi: number; seed: number; S: number }

/** Apply a clip's effect stack to `layer`. Pure function of (pixels, params, time, frame, seed). Returns the canvas holding the result. */
export function applyEffects(layer: Cv, buf: Cv, effects: EffectInst[], fx: FxCtx): Cv {
  let a = layer, b = buf; const W = a.width, H = a.height, S = fx.S;
  const swap = () => { const t = a; a = b; b = t; };
  for (const e of effects) {
    if (!e.enabled) continue;
    const p = e.params;
    switch (e.type) {
      case 'brightness': copy(b, a, `brightness(${1 + p.amount})`); swap(); break;
      case 'contrast': copy(b, a, `contrast(${1 + p.amount})`); swap(); break;
      case 'saturation': copy(b, a, `saturate(${Math.max(0, 1 + p.amount)})`); swap(); break;
      case 'exposure': copy(b, a, `brightness(${Math.pow(2, p.ev)})`); swap(); break;
      case 'blur': if (p.radius > 0) { copy(b, a, `blur(${p.radius * S}px)`); swap(); } break;
      case 'motionblur': {
        const x = clear(b), n = 8, len = p.amount * W * 0.04, ang = (p.angle * Math.PI) / 180;
        for (let i = 0; i < n; i++) { const o = (i / (n - 1) - 0.5) * len; x.globalAlpha = 1 / (i + 1); x.drawImage(a, Math.cos(ang) * o, Math.sin(ang) * o); }
        x.globalAlpha = 1; swap(); break;
      }
      case 'rgbsplit': {
        copy(b, a); const ang = (p.angle * Math.PI) / 180;
        rgbSplitInPlace(b, Math.cos(ang) * p.amount * S, Math.sin(ang) * p.amount * S); swap(); break;
      }
      case 'glitch': {
        const x = copy(b, a), key = Math.floor(fx.lt * p.rate), br = mulberry32(key * 31 + fx.seed)();
        if (br < 0.25 + 0.55 * p.intensity) {
          const r = mulberry32(fx.fi * 977 + fx.seed), n = 3 + Math.floor(p.intensity * 10);
          for (let i = 0; i < n; i++) {
            const y = Math.floor(r() * H), hh = Math.max(2, Math.floor(r() * H * 0.08)), dx = (r() - 0.5) * W * 0.18 * p.intensity;
            x.clearRect(0, y, W, hh); x.drawImage(a, 0, y, W, hh, dx, y, W, hh);
          }
          rgbSplitInPlace(b, (r() - 0.3) * 14 * p.intensity * S, 0);
        }
        swap(); break;
      }
      case 'shake': {
        const x = clear(b), t = fx.lt * p.speed, k = p.intensity;
        const dx = k * W * 0.02 * (Math.sin(t * 41.3) + 0.7 * Math.sin(t * 23.7 + 1)) / 1.7;
        const dy = k * H * 0.02 * (Math.sin(t * 37.1 + 2) + 0.7 * Math.sin(t * 19.3)) / 1.7;
        x.translate(W / 2 + dx, H / 2 + dy); x.rotate(k * 0.02 * Math.sin(t * 29)); const sc = 1 + k * 0.05; x.scale(sc, sc);
        x.drawImage(a, -W / 2, -H / 2); swap(); break;
      }
      case 'flash': {
        const x = copy(b, a), frac = (fx.lt * p.rate) % 1, pulse = Math.exp(-frac * 7) * (1 - Math.exp(-frac * 80));
        x.globalCompositeOperation = 'source-atop'; x.globalAlpha = clamp(p.intensity * pulse, 0, 1); x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
        x.globalAlpha = 1; x.globalCompositeOperation = 'source-over'; swap(); break;
      }
      case 'glow': {
        const x = copy(b, a); x.globalCompositeOperation = 'lighter'; x.globalAlpha = p.amount;
        x.filter = `blur(${p.radius * S}px) brightness(1.5)`; x.drawImage(a, 0, 0); x.filter = 'none'; x.globalAlpha = 1; x.globalCompositeOperation = 'source-over'; swap(); break;
      }
      case 'vhs': {
        const x = clear(b), amt = p.amount; x.filter = `saturate(${1 - 0.25 * amt}) contrast(${1 + 0.1 * amt})`;
        const bands = 36, bh = Math.ceil(H / bands), r = mulberry32(fx.fi * 313 + fx.seed), tear = Math.floor(r() * bands);
        for (let i = 0; i < bands; i++) {
          let dx = Math.sin(i * 0.7 + fx.lt * 5) * amt * 3 * S; if (i === tear || i === (tear + 1) % bands) dx += (r() - 0.3) * amt * 40 * S;
          x.drawImage(a, 0, i * bh, W, bh, dx, i * bh, W, bh);
        }
        x.filter = 'none'; rgbSplitInPlace(b, amt * 4 * S, 0);
        const pat = document.createElement('canvas'); pat.width = 1; pat.height = Math.max(3, Math.round(4 * S));
        const px = pat.getContext('2d')!; px.fillStyle = '#000'; px.fillRect(0, 0, 1, Math.max(1, Math.round(1.5 * S)));
        x.save(); x.globalCompositeOperation = 'source-atop'; x.globalAlpha = 0.3 * amt; x.fillStyle = x.createPattern(pat, 'repeat')!; x.fillRect(0, 0, W, H); x.restore();
        addGrain(b, a, amt * 0.35, fx.fi, S); swap(); break;
      }
      case 'grain': { copy(b, a); addGrain(b, a, p.amount, fx.fi, S); swap(); break; }
      case 'colorgrade': {
        const x = copy(b, a), id = x.getImageData(0, 0, W, H), d = id.data, tt = p.temp * 40, ti = p.tint * 30, f = p.fade;
        for (let i = 0; i < d.length; i += 4) {
          let r = d[i] + tt, g = d[i + 1] - ti, bl = d[i + 2] - tt;
          if (f) { r = r * (1 - f * 0.3) + 45 * f; g = g * (1 - f * 0.3) + 45 * f; bl = bl * (1 - f * 0.3) + 50 * f; }
          d[i] = r < 0 ? 0 : r > 255 ? 255 : r; d[i + 1] = g < 0 ? 0 : g > 255 ? 255 : g; d[i + 2] = bl < 0 ? 0 : bl > 255 ? 255 : bl;
        }
        x.putImageData(id, 0, 0);
        if (p.vignette > 0) {
          x.save(); x.globalCompositeOperation = 'source-atop';
          const g = x.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.hypot(W, H) * 0.55);
          g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${0.85 * p.vignette})`); x.fillStyle = g; x.fillRect(0, 0, W, H); x.restore();
        }
        swap(); break;
      }
    }
  }
  return a;
}
