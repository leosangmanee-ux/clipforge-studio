import type { Clip, Cue, Project, SubStyle } from '../types';
import { applyEffects, makeLayer } from './effects';
import { animState, drawTextBlock, type TextStyle } from './text';
import { hashStr, mulberry32 } from '../util';

export type SourceGetter = (clip: Clip) => CanvasImageSource | null;
const pool = new Map<string, HTMLCanvasElement>();
function layerPair(W: number, H: number): [HTMLCanvasElement, HTMLCanvasElement] {
  const k = `${W}x${H}`;
  if (!pool.has(k + 'a')) { pool.clear(); pool.set(k + 'a', makeLayer(W, H)); pool.set(k + 'b', makeLayer(W, H)); }
  return [pool.get(k + 'a')!, pool.get(k + 'b')!];
}

const srcSize = (s: CanvasImageSource): [number, number] =>
  s instanceof HTMLVideoElement ? [s.videoWidth, s.videoHeight] : s instanceof HTMLImageElement ? [s.naturalWidth, s.naturalHeight] : [(s as HTMLCanvasElement).width, (s as HTMLCanvasElement).height];

function drawMedia(x: CanvasRenderingContext2D, c: Clip, src: CanvasImageSource, W: number, H: number) {
  const [sw, sh] = srcSize(src); if (!sw || !sh) return;
  const cr = c.crop, sx = cr.l * sw, sy = cr.t * sh, cw = sw * (1 - cr.l - cr.r), ch = sh * (1 - cr.t - cr.b);
  if (cw <= 1 || ch <= 1) return;
  const f = (c.fit === 'cover' ? Math.max : Math.min)(W / cw, H / ch) * c.scale;
  x.save(); x.translate(W / 2 + c.x * W, H / 2 + c.y * H); x.rotate((c.rotate * Math.PI) / 180);
  x.drawImage(src, sx, sy, cw, ch, (-cw * f) / 2, (-ch * f) / 2, cw * f, ch * f); x.restore();
}

export const clipActive = (c: Clip, t: number) => t >= c.start - 1e-9 && t < c.start + c.dur - 1e-9;
export const isVisual = (c: Clip) => c.type !== 'audio';

/** The single compositor used by BOTH live preview and export. */
export function renderFrame(ctx: CanvasRenderingContext2D, p: Project, t: number, getSrc: SourceGetter) {
  const W = ctx.canvas.width, H = ctx.canvas.height, S = H / 1080, FPS = 30;
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; ctx.filter = 'none';
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  const z = (c: Clip) => p.tracks.find((tr) => tr.id === c.track)?.z ?? 0;
  const active = p.clips.filter((c) => isVisual(c) && clipActive(c, t)).sort((a, b) => z(a) - z(b));
  const [la, lb] = layerPair(W, H);
  for (const c of active) {
    const lt = t - c.start, fi = Math.floor(t * FPS + 1e-6);
    const lx = la.getContext('2d', { willReadFrequently: true })!;
    lx.setTransform(1, 0, 0, 1, 0, 0); lx.globalAlpha = 1; lx.globalCompositeOperation = 'source-over'; lx.filter = 'none'; lx.clearRect(0, 0, W, H);
    let alpha = c.opacity;
    if (c.type === 'text' && c.text) {
      const T = c.text, as = animState(T.animIn, T.animOut, lt, c.dur, W, H);
      alpha *= as.alpha;
      if (alpha > 0.001) {
        const rnd = mulberry32(fi * 131 + hashStr(c.id));
        drawTextBlock(lx, T.text, T as TextStyle, {
          cx: T.x * W, cy: T.y * H, W, S, rot: T.rotation, scale: as.scale, alpha: 1, offX: as.offX, offY: as.offY,
          reveal: as.reveal, kinetic: as.kinetic, glitch: as.glitch !== undefined ? { amt: as.glitch, rnd } : undefined,
        });
      }
    } else {
      const src = getSrc(c); if (src) drawMedia(lx, c, src, W, H);
    }
    if (alpha <= 0.001) continue;
    let out = la;
    const fxs = c.effects.filter((e) => e.enabled);
    if (fxs.length) out = applyEffects(la, lb, fxs, { lt, fi, seed: hashStr(c.id), S });
    ctx.globalAlpha = Math.min(1, alpha); ctx.drawImage(out, 0, 0); ctx.globalAlpha = 1;
  }
  drawSubtitles(ctx, p.cues, p.subStyle, t, W, H, S);
}

export const cueAt = (cues: Cue[], t: number) => cues.filter((c) => t >= c.start && t < c.end);

export function drawSubtitles(ctx: CanvasRenderingContext2D, cues: Cue[], s: SubStyle, t: number, W: number, H: number, S: number) {
  for (const cue of cueAt(cues, t)) {
    const st: TextStyle = {
      font: s.font, size: s.size, color: s.color, align: 'center', bold: s.bold, italic: false, outlineColor: s.outlineColor, outlineW: s.outlineW,
      shadow: false, shadowColor: '#000', shadowBlur: 0, shadowX: 0, shadowY: 0, gradient: false, color2: '#fff', gradAngle: 0,
      letterSpacing: 0, lineHeight: 1.25, boxW: 0.88,
    };
    // anchor the *bottom* of the block at s.y, so multi-line cues grow upward
    const lines = Math.max(1, cue.text.split('\n').length);
    drawTextBlock(ctx, cue.text, st, {
      cx: W / 2, cy: s.y * H - (lines - 1) * s.size * S * 0.6, W, S, rot: 0, scale: 1, alpha: 1,
      bg: s.bg ? { color: s.bgColor, opacity: s.bgOpacity } : undefined,
    });
  }
}
