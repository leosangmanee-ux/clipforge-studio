import type { Anim } from '../types';
import { FONT_STACK } from '../fonts';
import { clamp } from '../util';

const segG = new Intl.Segmenter('th', { granularity: 'grapheme' });
const segW = new Intl.Segmenter('th', { granularity: 'word' });
const pieces = (s: string, w: boolean) => Array.from((w ? segW : segG).segment(s), (x) => ({ text: x.segment, idx: x.index }));
const countG = (s: string) => pieces(s, false).length;

export interface TextStyle {
  font: string; size: number; color: string; align: 'left' | 'center' | 'right';
  bold: boolean; italic: boolean; outlineColor: string; outlineW: number;
  shadow: boolean; shadowColor: string; shadowBlur: number; shadowX: number; shadowY: number;
  gradient: boolean; color2: string; gradAngle: number; letterSpacing: number; lineHeight: number; boxW: number;
}
export interface DrawOpts {
  cx: number; cy: number; W: number; S: number; rot: number; scale: number; alpha: number;
  offX?: number; offY?: number;
  reveal?: number;               // typewriter 0..1
  kinetic?: number;              // kinetic progress 0..1
  glitch?: { amt: number; rnd: () => number };
  bg?: { color: string; opacity: number };
}

export const ease = {
  out: (x: number) => 1 - Math.pow(1 - x, 3),
  in: (x: number) => x * x * x,
  back: (x: number) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); },
  bounce: (x: number) => {
    const n1 = 7.5625, d1 = 2.75;
    if (x < 1 / d1) return n1 * x * x;
    if (x < 2 / d1) return n1 * (x -= 1.5 / d1) * x + 0.75;
    if (x < 2.5 / d1) return n1 * (x -= 2.25 / d1) * x + 0.9375;
    return n1 * (x -= 2.625 / d1) * x + 0.984375;
  },
};

function fontString(st: TextStyle, S: number) {
  return `${st.italic ? 'italic ' : ''}${st.bold ? 700 : 400} ${st.size * S}px ${FONT_STACK(st.font)}`;
}

function lineWidth(ctx: CanvasRenderingContext2D, s: string, ls: number) {
  return ctx.measureText(s).width + (ls ? ls * countG(s) : 0);
}
function wrap(ctx: CanvasRenderingContext2D, text: string, maxW: number, ls: number): string[] {
  const out: string[] = [];
  for (const para of text.split('\n')) {
    if (!para) { out.push(''); continue; }
    let cur = '';
    for (const w of pieces(para, true)) {
      const test = cur + w.text;
      if (cur.trim() && lineWidth(ctx, test.trimEnd(), ls) > maxW) { out.push(cur.trimEnd()); cur = w.text.trimStart(); }
      else cur = test;
    }
    out.push(cur);
  }
  return out;
}

/** Draw a text block centred at (cx, cy). Thai-safe: all splitting goes through Intl.Segmenter. */
export function drawTextBlock(ctx: CanvasRenderingContext2D, text: string, st: TextStyle, o: DrawOpts) {
  if (!text) return;
  const S = o.S, size = st.size * S, ls = st.letterSpacing * S;
  ctx.save();
  ctx.translate(o.cx + (o.offX ?? 0), o.cy + (o.offY ?? 0));
  ctx.rotate((o.rot * Math.PI) / 180); ctx.scale(o.scale, o.scale);
  ctx.globalAlpha *= o.alpha;
  ctx.font = fontString(st, S); ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
  const lines = wrap(ctx, text, st.boxW * o.W, ls);
  const lh = size * st.lineHeight, blockH = lh * lines.length;
  const widths = lines.map((l) => lineWidth(ctx, l, ls));
  const maxLW = Math.max(1, ...widths);
  const xStart = (i: number) => (st.align === 'center' ? -widths[i] / 2 : st.align === 'left' ? -maxLW / 2 : maxLW / 2 - widths[i]);
  const yBase = (i: number) => -blockH / 2 + lh * i + lh / 2 + size * 0.34;

  if (o.bg) {
    const pad = size * 0.3;
    ctx.save(); ctx.globalAlpha *= o.bg.opacity; ctx.fillStyle = o.bg.color;
    const bx = -maxLW / 2 - pad, by = -blockH / 2 - pad * 0.4, bw = maxLW + pad * 2, bh = blockH + pad * 0.8, r = pad * 0.6;
    ctx.beginPath(); (ctx as any).roundRect ? (ctx as any).roundRect(bx, by, bw, bh, r) : ctx.rect(bx, by, bw, bh); ctx.fill(); ctx.restore();
  }

  let fill: string | CanvasGradient = st.color;
  if (st.gradient) {
    const a = (st.gradAngle * Math.PI) / 180, dx = (Math.cos(a) * maxLW) / 2, dy = (Math.sin(a) * blockH) / 2 || 0.001;
    const g = ctx.createLinearGradient(-dx, -dy, dx, dy); g.addColorStop(0, st.color); g.addColorStop(1, st.color2); fill = g;
  }
  const totalG = lines.reduce((n, l) => n + countG(l), 0);
  const showG = o.reveal === undefined ? totalG : Math.floor(clamp(o.reveal, 0, 1) * totalG + 1e-6);
  const wordCount = lines.reduce((n, l) => n + pieces(l, true).filter((p) => /\S/.test(p.text)).length, 0);

  const paint = (s: string, x: number, y: number, colorOnly?: string) => {
    if (colorOnly) { ctx.fillStyle = colorOnly; ctx.fillText(s, x, y); return; }
    const setShadow = () => {
      if (!st.shadow) return;
      ctx.shadowColor = st.shadowColor; ctx.shadowBlur = st.shadowBlur * S; ctx.shadowOffsetX = st.shadowX * S; ctx.shadowOffsetY = st.shadowY * S;
    };
    const clearShadow = () => { ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; };
    if (st.outlineW > 0) {
      ctx.lineJoin = 'round'; ctx.miterLimit = 2; ctx.lineWidth = st.outlineW * S * 2; ctx.strokeStyle = st.outlineColor;
      setShadow(); ctx.strokeText(s, x, y); clearShadow();
      ctx.fillStyle = fill; ctx.fillText(s, x, y);
    } else { setShadow(); ctx.fillStyle = fill; ctx.fillText(s, x, y); clearShadow(); }
  };

  const pass = (dx: number, dy: number, colorOnly?: string) => {
    let remG = showG, wIdx = 0;
    lines.forEach((line, i) => {
      const x0 = xStart(i) + dx, y = yBase(i) + dy;
      const gs = pieces(line, false);
      if (o.kinetic !== undefined && o.kinetic < 1) {
        for (const w of pieces(line, true)) {
          const vis = /\S/.test(w.text); if (!vis) continue;
          const local = clamp((o.kinetic - (wIdx / Math.max(1, wordCount)) * 0.7) / 0.3, 0, 1); wIdx++;
          if (local <= 0) continue;
          const wx = x0 + ctx.measureText(line.slice(0, w.idx)).width, ww = ctx.measureText(w.text).width;
          ctx.save(); ctx.globalAlpha *= Math.min(1, local * 2);
          ctx.translate(wx + ww / 2, y - size * 0.3); const sc = 0.4 + 0.6 * ease.back(local); ctx.scale(sc, sc);
          ctx.translate(0, (1 - ease.out(local)) * size * 0.7);
          paint(w.text, -ww / 2, size * 0.3, colorOnly); ctx.restore();
        }
        return;
      }
      const vis = Math.min(gs.length, remG); remG -= gs.length;
      if (vis <= 0) return;
      if (!ls) {
        paint(vis === gs.length ? line : gs.slice(0, vis).map((g) => g.text).join(''), x0, y, colorOnly);
      } else {
        for (let k = 0; k < vis; k++) paint(gs[k].text, x0 + ctx.measureText(line.slice(0, gs[k].idx)).width + ls * k, y, colorOnly);
      }
    });
  };

  if (o.glitch && o.glitch.amt > 0) {
    const j = o.glitch.amt * size * 0.18, r = o.glitch.rnd;
    ctx.save(); ctx.globalAlpha *= 0.75;
    pass((r() - 0.3) * j, (r() - 0.5) * j * 0.3, '#ff2a6d'); pass((r() - 0.7) * j, (r() - 0.5) * j * 0.3, '#05d9e8');
    ctx.restore();
    pass((r() - 0.5) * j * 0.4, 0);
  } else pass(0, 0);
  ctx.restore();
}

export interface AnimState { alpha: number; offX: number; offY: number; scale: number; reveal?: number; kinetic?: number; glitch?: number }

/** Compute in/out animation state for a text clip at local time lt. */
export function animState(aIn: Anim, aOut: Anim, lt: number, D: number, W: number, H: number): AnimState {
  const st: AnimState = { alpha: 1, offX: 0, offY: 0, scale: 1 };
  if (aIn.type !== 'none') {
    const raw = (lt - aIn.delay) / Math.max(0.01, aIn.dur), p = clamp(raw, 0, 1);
    if (raw < 0) st.alpha = 0;
    else if (p < 1 || aIn.type === 'typewriter' || aIn.type === 'kinetic') {
      const dist = (d: Anim['dir']) => ({ left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] }[d]);
      switch (aIn.type) {
        case 'fade': st.alpha *= p; break;
        case 'slide': { const [dx, dy] = dist(aIn.dir); st.alpha *= clamp(p * 2, 0, 1); st.offX += dx * (1 - ease.out(p)) * W * 0.2; st.offY += dy * (1 - ease.out(p)) * H * 0.2; break; }
        case 'zoom': st.alpha *= clamp(p * 2, 0, 1); st.scale *= 0.3 + 0.7 * ease.out(p); break;
        case 'bounce': st.alpha *= clamp(p * 4, 0, 1); st.offY += (ease.bounce(p) - 1) * H * 0.35; break;
        case 'typewriter': st.reveal = p; break;
        case 'kinetic': st.kinetic = p; break;
        case 'glitch': st.glitch = 1 - p; st.alpha *= p < 0.15 ? (Math.floor(lt * 40) % 2 ? 0.2 : 1) : 1; break;
      }
    }
  }
  if (aOut.type !== 'none') {
    const raw = (lt - (D - aOut.dur)) / Math.max(0.01, aOut.dur), p = clamp(raw, 0, 1);
    if (p > 0) {
      const dist = ({ left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1] } as const)[aOut.dir];
      switch (aOut.type) {
        case 'fade': st.alpha *= 1 - p; break;
        case 'slide': st.alpha *= 1 - clamp(p * 1.5 - 0.5, 0, 1); st.offX += dist[0] * ease.in(p) * W * 0.2; st.offY += dist[1] * ease.in(p) * H * 0.2; break;
        case 'zoom': st.alpha *= 1 - p; st.scale *= 1 + 0.5 * ease.in(p); break;
      }
    }
  }
  return st;
}
