import './style.css';
import './fonts';
import { newProject, store } from './store';
import { Player } from './player';
import { Timeline } from './timeline';
import { Inspector } from './inspector';
import { addMediaClip, combineSelected, deleteSelected, splitAt } from './clips';
import { addMediaBlob, fetchUrl, releaseAllMedia, restoreMedia, runtime } from './media';
import * as db from './db';
import { fmtTime, h, toast } from './util';
import { openExportDialog } from './export';
import { ensureAllFonts } from './fonts';
import type { Project } from './types';

const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const app = $('app');
const player = new Player($('preview') as HTMLCanvasElement);
const timeline = new Timeline($('timeline'), player);
const inspector = new Inspector($('insp'), player);
(window as any).__cf = { store, player, timeline, inspector, runtime };

// ---------- transport ----------
const seek = $<HTMLInputElement>('seek'), timeEl = $('time'), playBtn = $('btn-play');
function updateTransport() {
  const d = player.duration;
  seek.max = String(Math.max(d, 0.01)); seek.value = String(player.t);
  timeEl.textContent = `${fmtTime(player.t)} / ${fmtTime(d)}`;
  playBtn.textContent = player.playing ? '⏸' : '▶';
  timeline.updatePlayhead();
}
player.onTick = updateTransport;
seek.addEventListener('input', () => player.seek(Number(seek.value)));
playBtn.onclick = () => player.toggle();
$('btn-start').onclick = () => player.seek(0);
$('btn-full').onclick = () => { const w = $('stage-wrap'); document.fullscreenElement ? document.exitFullscreen() : w.requestFullscreen?.(); };
$('btn-undo').onclick = () => store.undo();
$('btn-redo').onclick = () => store.redo();
$('btn-export').onclick = () => openExportDialog(player);
document.querySelectorAll<HTMLElement>('.mtabs [data-sheet]').forEach((b) => (b.onclick = () => (app.dataset.sheet = b.dataset.sheet!)));

// ---------- autosave ----------
const saveState = $('save-state'); let saveTimer = 0;
function scheduleSave() {
  saveState.textContent = 'Saving…'; clearTimeout(saveTimer);
  saveTimer = window.setTimeout(async () => {
    try { await db.putProject(store.p); saveState.textContent = '✓ Saved'; localStorage.setItem('clipforge:last', store.p.id); }
    catch { saveState.textContent = '⚠ Not saved'; }
  }, 700);
}
const topName = $<HTMLInputElement>('top-name');
topName.addEventListener('input', () => store.update((p) => (p.name = topName.value || 'Untitled'), { key: 'name', src: 'inspector' }));

store.on((src) => {
  if (src === 'load') { updateTransport(); }
  $('btn-undo').toggleAttribute('disabled', !store.canUndo()); $('btn-redo').toggleAttribute('disabled', !store.canRedo());
  if (document.activeElement !== topName) topName.value = store.p.name;
  if (src === 'select') { player.requestRender(); return; }
  player.resize(); player.refresh();
  if (player.t > player.duration) player.seek(player.duration); else updateTransport();
  renderMedia();
  if (src !== 'load') scheduleSave();
});

// ---------- media panel ----------
const mediaList = $('media-list'), bar = $('import-bar'), fill = $('import-fill'), msg = $('import-msg');
function renderMedia() {
  mediaList.replaceChildren(...store.p.media.map((m) => {
    const el = h('div', { class: 'mitem', draggable: true, 'data-media': m.id, title: 'Drag onto a track, or press Add' },
      h('span', { class: 'ic' }, m.kind === 'video' ? '🎞' : m.kind === 'audio' ? '♪' : '🖼'),
      h('div', { class: 'mn' }, m.name, h('small', {}, `${m.kind}${m.kind !== 'image' ? ` · ${fmtTime(m.duration, false).slice(0, 5)}` : ''}${m.width ? ` · ${m.width}×${m.height}` : ''}${m.kind === 'video' && !m.hasAudio ? ' · no audio' : ''}`)),
      h('button', { class: 'btn sm', 'data-act': 'add', title: 'Add to timeline at playhead', onclick: () => addMediaClip(m, player.t) }, '＋ Add'),
      h('button', { class: 'btn sm', title: 'Remove from project', onclick: () => {
        store.update((p) => { p.media = p.media.filter((x) => x.id !== m.id); p.clips = p.clips.filter((c) => c.mediaId !== m.id); });
        db.deleteMedia(m.id).catch(() => {});
      } }, '✕'));
    el.addEventListener('dragstart', (e) => e.dataTransfer?.setData('text/clipforge-media', m.id));
    return el;
  }));
}
function setBusy(frac: number | null, text = '') {
  bar.hidden = frac === null; if (frac !== null) fill.style.width = `${Math.round(frac * 100)}%`; msg.textContent = text;
}
async function importFiles(files: File[] | Blob[], names?: string[]) {
  let n = 0;
  for (let i = 0; i < files.length; i++) {
    const f = files[i] as File, name = names?.[i] ?? f.name;
    setBusy((i + 0.2) / files.length, `Importing ${name}…`);
    if (f.size > 600 * 1048576) toast(`${name} is ${(f.size / 1048576).toFixed(0)} MB — very large files may exhaust browser memory.`, 'info', 7000);
    try {
      const wasEmpty = store.p.clips.length === 0;
      const item = await addMediaBlob(store.p.id, f, name);
      store.update((p) => p.media.push(item), { src: 'ui' });
      if (wasEmpty && item.kind !== 'audio') addMediaClip(item, 0);
      n++;
    } catch (e: any) { toast(`${name}: ${e.message || e}`, 'error', 7000); }
  }
  setBusy(null); if (n) toast(`Imported ${n} file${n > 1 ? 's' : ''}.`, 'ok');
  player.fontsThenRender(); player.seek(player.t);
}
const fileInput = $<HTMLInputElement>('file-input');
$('btn-import').onclick = () => fileInput.click();
fileInput.onchange = () => { if (fileInput.files?.length) importFiles([...fileInput.files]); fileInput.value = ''; };
$('btn-url').onclick = async () => {
  const url = $<HTMLInputElement>('url-input').value; if (!url.trim()) return;
  try {
    setBusy(0, 'Connecting…');
    const { blob, name } = await fetchUrl(url, (f, t) => setBusy(f, `Downloading… ${t}`));
    await importFiles([blob], [name]);
  } catch (e: any) { setBusy(null); toast(e.message || String(e), 'error', 9000); }
};
const dz = $('dropzone');
addEventListener('dragover', (e) => { if (e.dataTransfer?.types.includes('Files')) { e.preventDefault(); dz.classList.add('drag'); } });
addEventListener('dragleave', (e) => { if (!(e as DragEvent).relatedTarget) dz.classList.remove('drag'); });
addEventListener('drop', (e) => {
  dz.classList.remove('drag');
  if (e.dataTransfer?.files.length) { e.preventDefault(); importFiles([...e.dataTransfer.files]); }
});

// ---------- projects ----------
async function loadProject(p: Project) {
  player.pause(); releaseAllMedia();
  const missing: string[] = [];
  for (const m of p.media) {
    const row = await db.getMedia(m.id).catch(() => undefined);
    if (row) { try { await restoreMedia(m, row.blob); } catch { missing.push(m.name); } } else missing.push(m.name);
  }
  store.setProject(p); player.seek(0); player.fontsThenRender();
  if (missing.length) toast(`Could not restore media: ${missing.join(', ')}. (Clips that used it will be blank — re-import the file.)`, 'error', 9000);
}
async function newProj() {
  await db.putProject(store.p).catch(() => {}); releaseAllMedia();
  store.setProject(newProject()); player.seek(0); await db.putProject(store.p).catch(() => {}); localStorage.setItem('clipforge:last', store.p.id);
}
async function openProjects() {
  await db.putProject(store.p).catch(() => {});
  const list = h('div', { id: 'proj-list' });
  const modal = h('div', { class: 'modal', id: 'projects-modal' }, h('div', { class: 'dlg' }, h('h3', {}, 'Projects'),
    h('div', { class: 'btnrow' }, h('button', { class: 'btn primary', id: 'proj-new', onclick: async () => { await newProj(); modal.remove(); } }, '＋ New project')),
    list, h('div', { class: 'btnrow' }, h('button', { class: 'btn', onclick: () => modal.remove() }, 'Close'))));
  const fillList = async () => {
    const rows = (await db.listProjects()).sort((a, b) => b.updated - a.updated);
    list.replaceChildren(...rows.map((r) => {
      const nm = h('input', { class: 'txt', value: r.name });
      nm.addEventListener('change', async () => {
        if (r.id === store.p.id) store.update((p) => (p.name = nm.value || 'Untitled'));
        else { const pr = JSON.parse(r.data) as Project; pr.name = nm.value || 'Untitled'; await db.putProject(pr); }
      });
      return h('div', { class: 'prow', 'data-pid': r.id }, nm, h('span', { class: 'dim sm' }, new Date(r.updated).toLocaleString()),
        h('button', { class: 'btn sm', 'data-act': 'open', disabled: r.id === store.p.id, onclick: async () => { await db.putProject(store.p); await loadProject(JSON.parse(r.data)); localStorage.setItem('clipforge:last', r.id); modal.remove(); } }, r.id === store.p.id ? 'Open ✓' : 'Open'),
        h('button', { class: 'btn sm', disabled: r.id === store.p.id, title: 'Delete', onclick: async () => { await db.deleteProject(r.id); fillList(); } }, '✕'));
    }));
  };
  document.body.append(modal); fillList();
}
$('btn-projects').onclick = openProjects;

// ---------- keyboard ----------
addEventListener('keydown', (e) => {
  const tag = (e.target as HTMLElement).tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') { if (!(e.ctrlKey || e.metaKey)) return; if (tag !== 'INPUT' || (e.target as HTMLInputElement).type === 'text' || (e.target as HTMLInputElement).type === 'number') return; }
  const mod = e.ctrlKey || e.metaKey;
  if (e.code === 'Space') { e.preventDefault(); player.toggle(); }
  else if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? store.redo() : store.undo(); }
  else if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); store.redo(); }
  else if (e.key.toLowerCase() === 's' && !mod) { splitAt(player.t); }
  else if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); deleteSelected(); }
  else if (e.key === 'ArrowLeft') player.seek(player.t - (e.shiftKey ? 1 : 1 / 30));
  else if (e.key === 'ArrowRight') player.seek(player.t + (e.shiftKey ? 1 : 1 / 30));
  else if (e.key.toLowerCase() === 'j' && mod) { e.preventDefault(); toast(combineSelected(), 'info'); }
});

// ---------- boot ----------
(async () => {
  await ensureAllFonts();
  let opened = false;
  try {
    const last = localStorage.getItem('clipforge:last');
    const row = last ? await db.getProject(last) : undefined;
    if (row) { await loadProject(JSON.parse(row.data)); opened = true; }
  } catch { /* fresh start */ }
  if (!opened) { store.setProject(newProject()); }
  player.seek(0); renderMedia(); updateTransport();
  (window as any).__cfReady = true;
})();
