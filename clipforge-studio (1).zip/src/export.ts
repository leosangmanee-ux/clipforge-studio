import type { Project } from './types';
import { canvasSize, projectDuration, store } from './store';
import { runtime } from './media';
import { mixToWav } from './audio';
import { clipActive, renderFrame } from './render/frame';
import { ensureFont } from './fonts';
import { download, h, toast } from './util';
import type { Player } from './player';

export interface ExportOpts { res: 720 | 1080; fps: 30 | 60 }
type Progress = (phase: string, frac: number) => void;

let ffmpeg: any = null;
async function getFFmpeg(onLog: (m: string) => void) {
  if (ffmpeg) return ffmpeg;
  const { FFmpeg } = await import('@ffmpeg/ffmpeg');
  const { toBlobURL } = await import('@ffmpeg/util');
  const ff = new FFmpeg();
  ff.on('log', ({ message }: { message: string }) => onLog(message));
  const base = `${import.meta.env.BASE_URL}ffmpeg`.replace(/\/\//g, '/');
  await ff.load({
    coreURL: await toBlobURL(`${base}/ffmpeg-core.js`, 'text/javascript'),
    wasmURL: await toBlobURL(`${base}/ffmpeg-core.wasm`, 'application/wasm'),
  });
  return (ffmpeg = ff);
}

function seekTo(v: HTMLVideoElement, time: number) {
  return new Promise<void>((res) => {
    if (Math.abs(v.currentTime - time) < 0.0005 && v.readyState >= 2) return res();
    let done = false; const fin = () => { if (done) return; done = true; v.removeEventListener('seeked', fin); res(); };
    v.addEventListener('seeked', fin); v.currentTime = time; setTimeout(fin, 5000);
  });
}
function loadVideo(url: string) {
  return new Promise<HTMLVideoElement>((res, rej) => {
    const v = document.createElement('video'); v.muted = true; v.preload = 'auto'; v.playsInline = true;
    v.onloadeddata = () => res(v); v.onerror = () => rej(new Error('Could not load a source video for export.')); v.src = url;
  });
}
const toJpeg = (cv: HTMLCanvasElement) => new Promise<Blob>((res, rej) => cv.toBlob((b) => (b ? res(b) : rej(new Error('Frame encode failed'))), 'image/jpeg', 0.93));

export function estimate(p: Project, o: ExportOpts) {
  const [W, H] = canvasSize(p.aspect, o.res), dur = projectDuration(p), frames = Math.ceil(dur * o.fps);
  return { W, H, dur, frames, bytes: frames * W * H * 0.17 };
}

export async function exportMp4(p: Project, o: ExportOpts, onProgress: Progress, signal: AbortSignal): Promise<Blob> {
  const { W, H, dur, frames, bytes } = estimate(p, o);
  if (dur <= 0) throw new Error('The timeline is empty — add a clip first.');
  if (bytes > 1.4e9) throw new Error(`This export would need about ${(bytes / 1e9).toFixed(1)} GB of browser memory. Shorten the project, or use 720p / 30 FPS.`);
  const chk = () => { if (signal.aborted) throw new DOMException('Export cancelled', 'AbortError'); };

  onProgress('Preparing fonts', 0);
  await Promise.all([...p.clips.filter((c) => c.text).map((c) => ensureFont(c.text!.font, c.text!.bold, c.text!.text)), ensureFont(p.subStyle.font, p.subStyle.bold, p.cues.map((c) => c.text).join(''))]);
  chk();
  onProgress('Mixing audio', 0);
  const wav = await mixToWav(p, dur);
  chk();
  onProgress('Loading encoder', 0);
  const logs: string[] = [];
  const ff = await getFFmpeg((m) => { logs.push(m); if (logs.length > 40) logs.shift(); });
  chk();

  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d')!;
  const vids = new Map<string, HTMLVideoElement>();
  for (const c of p.clips) if (c.type === 'video' && c.mediaId) { const rt = runtime.get(c.mediaId); if (rt) vids.set(c.id, await loadVideo(rt.url)); }
  const written: string[] = [];
  const cleanup = async () => {
    for (const f of [...written, 'audio.wav', 'out.mp4']) { try { await ff.deleteFile(f); } catch { /* */ } }
    for (const v of vids.values()) { v.removeAttribute('src'); v.load(); }
  };
  try {
    for (let i = 0; i < frames; i++) {
      chk();
      const t = i / o.fps;
      for (const c of p.clips) {
        if (c.type !== 'video' || !clipActive(c, t)) continue;
        const v = vids.get(c.id); if (!v) continue;
        await seekTo(v, Math.min(c.in + (t - c.start) * c.speed, Math.max(0, v.duration - 0.001)));
      }
      renderFrame(ctx, p, t, (c) => (c.type === 'video' ? vids.get(c.id) ?? null : c.type === 'image' ? runtime.get(c.mediaId!)?.img ?? null : null));
      const name = `f${String(i).padStart(6, '0')}.jpg`;
      await ff.writeFile(name, new Uint8Array(await (await toJpeg(cv)).arrayBuffer())); written.push(name);
      if (i % 3 === 0 || i === frames - 1) onProgress('Rendering frames', (i + 1) / frames);
    }
    chk();
    await ff.writeFile('audio.wav', new Uint8Array(await wav.arrayBuffer()));
    const onProg = ({ progress }: { progress: number }) => onProgress('Encoding H.264 + AAC', Math.min(1, Math.max(0, progress)));
    ff.on('progress', onProg); onProgress('Encoding H.264 + AAC', 0);
    const abort = () => { try { ff.terminate(); } catch { /* */ } ffmpeg = null; };
    signal.addEventListener('abort', abort, { once: true });
    let code: number;
    try {
      code = await ff.exec(['-y', '-framerate', String(o.fps), '-i', 'f%06d.jpg', '-i', 'audio.wav',
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-r', String(o.fps),
        '-c:a', 'aac', '-b:a', '192k', '-ar', '44100', '-movflags', '+faststart', 'out.mp4']);
    } finally { ff.off('progress', onProg); signal.removeEventListener('abort', abort); }
    chk();
    if (code !== 0) throw new Error('Encoder failed:\n' + logs.slice(-6).join('\n'));
    onProgress('Finalizing', 1);
    const data = (await ff.readFile('out.mp4')) as Uint8Array;
    return new Blob([data.slice().buffer], { type: 'video/mp4' });
  } finally { if (ffmpeg) await cleanup(); }
}

export function openExportDialog(player: Player) {
  player.pause();
  const p = store.p;
  const res = h('select', { id: 'ex-res' }, h('option', { value: 720 }, '720p'), h('option', { value: 1080 }, '1080p'));
  const fps = h('select', { id: 'ex-fps' }, h('option', { value: 30 }, '30 FPS'), h('option', { value: 60 }, '60 FPS'));
  const asp = h('select', { id: 'ex-aspect' }, ...(['16:9', '9:16', '1:1'] as const).map((a) => h('option', { value: a, selected: a === p.aspect }, a)));
  const info = h('div', { class: 'hint' });
  const bar = h('div', { class: 'bar' }, h('i', { id: 'ex-bar-fill' })), phase = h('div', { class: 'phase', id: 'ex-phase' }, 'Ready');
  const result = h('div', { class: 'ex-result', id: 'ex-result' });
  const go = h('button', { class: 'btn primary', id: 'ex-start' }, '▶ Start export'), cancel = h('button', { class: 'btn', id: 'ex-cancel' }, 'Close');
  const upd = () => {
    const e = estimate(store.p, { res: Number(res.value) as any, fps: Number(fps.value) as any });
    info.textContent = `${e.W}×${e.H} · ${e.dur.toFixed(1)} s · ${e.frames} frames · est. memory ≈ ${(e.bytes / 1e6).toFixed(0)} MB` + (e.bytes > 8e8 ? ' — large: may be slow or run out of memory.' : '');
  };
  asp.addEventListener('change', () => { store.update((pp) => (pp.aspect = asp.value as any)); player.resize(); upd(); });
  res.addEventListener('change', upd); fps.addEventListener('change', upd); upd();
  const overlay = h('div', { class: 'modal', id: 'export-modal' }, h('div', { class: 'dlg' },
    h('h3', {}, 'Export MP4'),
    h('div', { class: 'row' }, h('span', { class: 'rl' }, 'Aspect'), h('div', { class: 'rc' }, asp)),
    h('div', { class: 'row' }, h('span', { class: 'rl' }, 'Resolution'), h('div', { class: 'rc' }, res)),
    h('div', { class: 'row' }, h('span', { class: 'rl' }, 'Frame rate'), h('div', { class: 'rc' }, fps)),
    info, bar, phase, result, h('div', { class: 'btnrow' }, go, cancel)));
  document.body.append(overlay);
  let ctl: AbortController | null = null;
  cancel.onclick = () => { ctl?.abort(); overlay.remove(); };
  go.onclick = async () => {
    ctl = new AbortController(); go.setAttribute('disabled', ''); result.replaceChildren();
    (overlay.querySelectorAll('select') as NodeListOf<HTMLSelectElement>).forEach((s) => (s.disabled = true));
    cancel.textContent = 'Cancel';
    const fill = document.getElementById('ex-bar-fill')!;
    const prog: Progress = (ph, f) => { phase.textContent = `${ph}… ${Math.round(f * 100)}%`; fill.style.width = `${f * 100}%`; };
    try {
      const blob = await exportMp4(store.p, { res: Number(res.value) as any, fps: Number(fps.value) as any }, prog, ctl.signal);
      const url = URL.createObjectURL(blob), name = `${store.p.name || 'clipforge'}.mp4`;
      phase.textContent = `Done — ${(blob.size / 1e6).toFixed(2)} MB`; fill.style.width = '100%';
      const vid = h('video', { src: url, controls: true, class: 'ex-prev' });
      result.append(vid, h('a', { class: 'btn primary', id: 'ex-download', href: url, download: name }, '⬇ Download MP4'));
      (window as any).__lastExport = blob;
      cancel.textContent = 'Close';
    } catch (e: any) {
      if (e?.name === 'AbortError') { phase.textContent = 'Cancelled'; }
      else { phase.textContent = 'Export failed'; result.append(h('pre', { class: 'err', id: 'ex-error' }, String(e?.message ?? e))); toast('Export failed — see the dialog for details.', 'error'); console.error(e); }
      cancel.textContent = 'Close';
    } finally {
      go.removeAttribute('disabled'); go.textContent = '▶ Export again';
      (overlay.querySelectorAll('select') as NodeListOf<HTMLSelectElement>).forEach((s) => (s.disabled = false));
    }
  };
  void download;
}
