import type { MediaItem } from './types';
import { uid } from './util';
import { putMedia } from './db';

export interface Runtime {
  blob: Blob; url: string; img?: HTMLImageElement; buffer?: AudioBuffer; peaks?: Float32Array;
}
export const runtime = new Map<string, Runtime>();
export const PEAKS_PER_SEC = 50;

let actx: AudioContext | null = null;
export const audioCtx = () => (actx ??= new AudioContext());

const EXT_VIDEO = /\.(mp4|m4v|mov|webm|mkv|ogv)$/i, EXT_AUDIO = /\.(mp3|wav|m4a|aac|ogg|oga|flac|opus)$/i, EXT_IMG = /\.(png|jpe?g|gif|webp|bmp|avif)$/i;
export function kindOf(name: string, type: string): MediaItem['kind'] | null {
  if (type.startsWith('video/') || EXT_VIDEO.test(name)) return 'video';
  if (type.startsWith('audio/') || EXT_AUDIO.test(name)) return 'audio';
  if (type.startsWith('image/') || EXT_IMG.test(name)) return 'image';
  return null;
}

const MAX_DECODE_BYTES = 400 * 1024 * 1024;

function computePeaks(buf: AudioBuffer) {
  const n = Math.max(1, Math.ceil(buf.duration * PEAKS_PER_SEC));
  const peaks = new Float32Array(n);
  const ch = buf.getChannelData(0), per = Math.max(1, Math.floor(buf.sampleRate / PEAKS_PER_SEC));
  for (let i = 0; i < n; i++) {
    let m = 0; const e = Math.min(ch.length, (i + 1) * per);
    for (let j = i * per; j < e; j += 4) { const v = Math.abs(ch[j]); if (v > m) m = v; }
    peaks[i] = m;
  }
  return peaks;
}

export async function decodeAudio(id: string, blob: Blob) {
  const rt = runtime.get(id)!;
  if (blob.size > MAX_DECODE_BYTES) return false;
  try {
    const ab = await blob.arrayBuffer();
    rt.buffer = await audioCtx().decodeAudioData(ab);
    rt.peaks = computePeaks(rt.buffer);
    return rt.buffer.numberOfChannels > 0 && rt.buffer.length > 0;
  } catch { return false; }
}

function probeVideo(url: string): Promise<{ duration: number; width: number; height: number }> {
  return new Promise((res, rej) => {
    const v = document.createElement('video');
    v.preload = 'metadata'; v.muted = true;
    v.onloadedmetadata = () => res({ duration: v.duration, width: v.videoWidth, height: v.videoHeight });
    v.onerror = () => rej(new Error('This video format cannot be played by the browser.'));
    v.src = url;
  });
}
function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('Cannot decode image.')); i.src = url;
  });
}

/** Register a blob as media for a project: probe it, decode audio, persist it. */
export async function addMediaBlob(projectId: string, blob: Blob, name: string, forcedId?: string, persist = true): Promise<MediaItem> {
  const kind = kindOf(name, blob.type);
  if (!kind) throw new Error(`Unsupported file type: ${name}`);
  const id = forcedId ?? uid();
  const url = URL.createObjectURL(blob);
  runtime.set(id, { blob, url });
  let item: MediaItem;
  try {
    if (kind === 'video') {
      const m = await probeVideo(url);
      item = { id, name, kind, ...m, hasAudio: false };
      item.hasAudio = await decodeAudio(id, blob);
    } else if (kind === 'audio') {
      item = { id, name, kind, duration: 0, width: 0, height: 0, hasAudio: true };
      const ok = await decodeAudio(id, blob);
      if (!ok) throw new Error('Cannot decode this audio file.');
      item.duration = runtime.get(id)!.buffer!.duration;
    } else {
      const img = await loadImage(url);
      runtime.get(id)!.img = img;
      item = { id, name, kind, duration: 5, width: img.naturalWidth, height: img.naturalHeight, hasAudio: false };
    }
  } catch (e) { runtime.delete(id); URL.revokeObjectURL(url); throw e; }
  if (persist) await putMedia(id, projectId, blob);
  return item;
}

/** Restore a stored blob (project reopen) – no re-persist. */
export async function restoreMedia(item: MediaItem, blob: Blob) {
  const url = URL.createObjectURL(blob);
  runtime.set(item.id, { blob, url });
  if (item.kind === 'image') runtime.get(item.id)!.img = await loadImage(url);
  else await decodeAudio(item.id, blob);
}
export function releaseAllMedia() {
  for (const r of runtime.values()) URL.revokeObjectURL(r.url);
  runtime.clear();
}

const PLATFORM = /(^|\.)(youtube\.com|youtu\.be|tiktok\.com|facebook\.com|fb\.watch|instagram\.com|twitter\.com|x\.com|vimeo\.com|netflix\.com|dailymotion\.com|twitch\.tv)$/i;

/** Import a direct video/audio/image URL. Platform pages are refused with an explanation. */
export async function fetchUrl(
  raw: string, onProgress: (frac: number, msg: string) => void
): Promise<{ blob: Blob; name: string }> {
  let u: URL;
  try { u = new URL(raw.trim()); } catch { throw new Error('That is not a valid URL.'); }
  if (!/^https?:$/.test(u.protocol)) throw new Error('Only http(s) links to a direct video, audio or image file are supported.');
  if (PLATFORM.test(u.hostname))
    throw new Error(`${u.hostname} is a streaming platform page, not a direct media file, and the platform does not allow downloading it here. Please download the video yourself if you have the right to, then upload the file.`);
  let resp: Response;
  try { resp = await fetch(u.href); } catch {
    throw new Error('The server did not allow the browser to download this file (CORS or network error). Download it manually and upload it instead.');
  }
  if (!resp.ok) throw new Error(`Download failed: HTTP ${resp.status}. If the link needs a login, download the file yourself and upload it.`);
  const type = resp.headers.get('content-type') || '';
  const name = decodeURIComponent(u.pathname.split('/').pop() || 'download') || 'download';
  if (!kindOf(name, type.split(';')[0])) throw new Error(`This link returns "${type || 'unknown type'}", not a direct video, audio or image file.`);
  const total = Number(resp.headers.get('content-length')) || 0;
  if (!resp.body) return { blob: await resp.blob(), name };
  const reader = resp.body.getReader(); const parts: Uint8Array[] = []; let got = 0;
  for (;;) {
    const { done, value } = await reader.read(); if (done) break;
    parts.push(value); got += value.length;
    onProgress(total ? got / total : 0, `${(got / 1048576).toFixed(1)} MB${total ? ` / ${(total / 1048576).toFixed(1)} MB` : ''}`);
  }
  return { blob: new Blob(parts as BlobPart[], { type: type.split(';')[0] }), name: /\.\w{2,5}$/.test(name) ? name : name + '.mp4' };
}
