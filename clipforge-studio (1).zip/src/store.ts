import type { Aspect, Clip, Project, Track } from './types';
import { uid } from './util';

export const DEFAULT_TRACKS: Track[] = [
  { id: 'T2', name: 'Text 2', kind: 'text', z: 5 },
  { id: 'T1', name: 'Text 1', kind: 'text', z: 4 },
  { id: 'V2', name: 'Overlay', kind: 'video', z: 2 },
  { id: 'V1', name: 'Video', kind: 'video', z: 1 },
  { id: 'A1', name: 'Audio', kind: 'audio', z: 0 },
  { id: 'A2', name: 'Music/SFX', kind: 'audio', z: 0 },
];

export function newProject(name = 'Untitled project'): Project {
  return {
    id: uid(), name, aspect: '16:9', fps: 30,
    tracks: JSON.parse(JSON.stringify(DEFAULT_TRACKS)), clips: [], cues: [],
    subStyle: {
      font: 'Noto Sans Thai', size: 44, color: '#ffffff', outlineColor: '#000000', outlineW: 3,
      bold: true, bg: false, bgColor: '#000000', bgOpacity: 0.5, y: 0.88,
    },
    media: [], updated: Date.now(),
  };
}

export function canvasSize(aspect: Aspect, short = 720): [number, number] {
  if (aspect === '9:16') return [short, Math.round((short * 16) / 9 / 2) * 2];
  if (aspect === '1:1') return [short, short];
  return [Math.round((short * 16) / 9 / 2) * 2, short];
}

export const projectDuration = (p: Project) =>
  Math.max(0, ...p.clips.map((c) => c.start + c.dur), ...p.cues.map((c) => c.end));

type Listener = (src: string) => void;

class Store {
  p: Project = newProject();
  sel: string[] = [];
  selCue: string | null = null;
  private listeners: Listener[] = [];
  private undoStack: string[] = [];
  private redoStack: string[] = [];
  private lastKey = ''; private lastKeyAt = 0;

  on(fn: Listener) { this.listeners.push(fn); }
  emit(src = 'ui') { this.p.updated = Date.now(); for (const l of this.listeners) l(src); }

  setProject(p: Project) {
    this.p = p; this.sel = []; this.selCue = null;
    this.undoStack = []; this.redoStack = []; this.emit('load');
  }
  /** Save an undo snapshot. Calls with the same key within 1s coalesce (slider drags). */
  checkpoint(key = '') {
    const now = performance.now();
    if (key && key === this.lastKey && now - this.lastKeyAt < 1000) { this.lastKeyAt = now; return; }
    this.lastKey = key; this.lastKeyAt = now;
    this.undoStack.push(JSON.stringify(this.p));
    if (this.undoStack.length > 100) this.undoStack.shift();
    this.redoStack = [];
  }
  update(fn: (p: Project) => void, opts: { key?: string; src?: string } = {}) {
    this.checkpoint(opts.key ?? '');
    fn(this.p);
    this.emit(opts.src ?? 'ui');
  }
  undo() {
    const s = this.undoStack.pop(); if (!s) return;
    this.redoStack.push(JSON.stringify(this.p)); this.p = JSON.parse(s); this.fixSel(); this.lastKey = ''; this.emit('undo');
  }
  redo() {
    const s = this.redoStack.pop(); if (!s) return;
    this.undoStack.push(JSON.stringify(this.p)); this.p = JSON.parse(s); this.fixSel(); this.lastKey = ''; this.emit('undo');
  }
  private fixSel() {
    this.sel = this.sel.filter((id) => this.p.clips.some((c) => c.id === id));
    if (this.selCue && !this.p.cues.some((c) => c.id === this.selCue)) this.selCue = null;
  }
  select(ids: string[]) { this.sel = ids; this.selCue = null; this.emit('select'); }
  clip(id: string) { return this.p.clips.find((c) => c.id === id); }
  get selClip(): Clip | undefined { return this.sel.length === 1 ? this.clip(this.sel[0]) : undefined; }
  track(id: string) { return this.p.tracks.find((t) => t.id === id)!; }
  canUndo() { return this.undoStack.length > 0; }
  canRedo() { return this.redoStack.length > 0; }
}
export const store = new Store();

/** Find the nearest non-overlapping start for a clip of length `dur` on `track`. */
export function findFree(p: Project, track: string, start: number, dur: number, excludeId?: string): number | null {
  const others = p.clips.filter((c) => c.track === track && c.id !== excludeId);
  const ok = (s: number) => s >= -1e-6 && others.every((o) => s + dur <= o.start + 1e-6 || s >= o.start + o.dur - 1e-6);
  const cands = [start, 0, ...others.map((o) => o.start + o.dur), ...others.map((o) => o.start - dur)]
    .map((s) => Math.max(0, s)).filter(ok);
  if (!cands.length) return null;
  return cands.sort((a, b) => Math.abs(a - start) - Math.abs(b - start))[0];
}
