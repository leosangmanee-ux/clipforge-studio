import '@fontsource/noto-sans-thai/latin-400.css'; import '@fontsource/noto-sans-thai/latin-700.css';
import '@fontsource/noto-sans-thai/thai-400.css'; import '@fontsource/noto-sans-thai/thai-700.css';
import '@fontsource/sarabun/latin-400.css'; import '@fontsource/sarabun/latin-700.css';
import '@fontsource/sarabun/thai-400.css'; import '@fontsource/sarabun/thai-700.css';
import '@fontsource/prompt/latin-400.css'; import '@fontsource/prompt/latin-700.css';
import '@fontsource/prompt/thai-400.css'; import '@fontsource/prompt/thai-700.css';
import '@fontsource/kanit/latin-400.css'; import '@fontsource/kanit/latin-700.css';
import '@fontsource/kanit/thai-400.css'; import '@fontsource/kanit/thai-700.css';
import '@fontsource/bebas-neue/latin-400.css';
import '@fontsource/montserrat/latin-400.css'; import '@fontsource/montserrat/latin-700.css';
import '@fontsource/inter/latin-400.css'; import '@fontsource/inter/latin-700.css';
import '@fontsource/pacifico/latin-400.css';

export const FONTS = [
  { name: 'Noto Sans Thai', label: 'Noto Sans Thai (TH/EN)' },
  { name: 'Sarabun', label: 'Sarabun (TH/EN)' },
  { name: 'Prompt', label: 'Prompt (TH/EN)' },
  { name: 'Kanit', label: 'Kanit (TH/EN)' },
  { name: 'Montserrat', label: 'Montserrat (EN)' },
  { name: 'Inter', label: 'Inter (EN)' },
  { name: 'Bebas Neue', label: 'Bebas Neue (EN display)' },
  { name: 'Pacifico', label: 'Pacifico (EN script)' },
];
export const FONT_STACK = (f: string) => `"${f}", "Noto Sans Thai", sans-serif`;

/** Make sure the exact face (incl. Thai subset) is loaded before canvas drawing. */
export async function ensureFont(family: string, bold: boolean, sample = '') {
  const spec = `${bold ? 700 : 400} 40px "${family}"`;
  const txt = `Aa สวัสดีภาษาไทย ${sample}`;
  try {
    await Promise.all([document.fonts.load(spec, txt), document.fonts.load(`${bold ? 700 : 400} 40px "Noto Sans Thai"`, txt)]);
  } catch { /* ignore */ }
}
export async function ensureAllFonts() {
  await Promise.all(FONTS.flatMap((f) => [ensureFont(f.name, false), ensureFont(f.name, true)]));
}
