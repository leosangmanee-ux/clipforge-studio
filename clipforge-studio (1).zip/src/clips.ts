import type { Clip, ClipType, EffectInst, MediaItem, TextProps } from './types';
import { findFree, store } from './store';
import { uid } from './util';
import { defaultParams } from './render/effects';

export const noAnim = { type: 'none', dur: 0.6, delay: 0, dir: 'left' as const };
export function defaultText(text = 'สวัสดี Hello'): TextProps {
  return {
    text, font: 'Noto Sans Thai', size: 96, color: '#ffffff', align: 'center', bold: true, italic: false,
    outlineColor: '#000000', outlineW: 4, shadow: true, shadowColor: '#000000', shadowBlur: 12, shadowX: 0, shadowY: 4,
    gradient: false, color2: '#8b5cf6', gradAngle: 90, letterSpacing: 0, lineHeight: 1.2, x: 0.5, y: 0.5, rotation: 0, boxW: 0.9,
    animIn: { ...noAnim, type: 'fade' }, animOut: { ...noAnim, type: 'fade' },
  };
}
export function baseClip(type: ClipType, track: string, start: number, dur: number): Clip {
  return {
    id: uid(), track, type, label: '', start, dur, in: 0, speed: 1, volume: 1, fadeIn: 0, fadeOut: 0, muted: false,
    x: 0, y: 0, scale: 1, rotate: 0, opacity: 1, fit: 'contain', crop: { l: 0, t: 0, r: 0, b: 0 }, effects: [],
  };
}
export function newEffect(type: string): EffectInst { return { id: uid(), type, enabled: true, params: defaultParams(type) }; }

const tracksOfKind = (kind: string) => store.p.tracks.filter((t) => t.kind === kind).reverse(); // bottom-most first (V1, V2 / A1, A2)

/** Place a media item on the first track that has room at `start`. */
export function addMediaClip(m: MediaItem, start: number, preferTrack?: string): Clip | null {
  const type: ClipType = m.kind;
  const kind = m.kind === 'audio' ? 'audio' : 'video';
  const order = tracksOfKind(kind);
  if (preferTrack) order.sort((a, b) => (a.id === preferTrack ? -1 : b.id === preferTrack ? 1 : 0));
  const dur = m.duration || 5;
  for (const tr of order) {
    const s = findFree(store.p, tr.id, start, dur);
    if (s !== null && Math.abs(s - start) < 1e-6) return make(tr.id, s);
  }
  // nothing free exactly at `start`: append after the end of the first track
  const tr = order[0], end = Math.max(0, ...store.p.clips.filter((c) => c.track === tr.id).map((c) => c.start + c.dur));
  return make(tr.id, end);
  function make(track: string, s: number) {
    const c = baseClip(type, track, s, dur);
    c.mediaId = m.id; c.label = m.name; c.fit = 'contain';
    store.update((p) => p.clips.push(c)); store.select([c.id]); return c;
  }
}

export function addTextClip(start: number, text?: string): Clip | null {
  const dur = 3;
  for (const tr of tracksOfKind('text')) {
    const s = findFree(store.p, tr.id, start, dur);
    if (s !== null && Math.abs(s - start) < 1e-6) return make(tr.id, s);
  }
  const tr = tracksOfKind('text')[0];
  const end = Math.max(0, ...store.p.clips.filter((c) => c.track === tr.id).map((c) => c.start + c.dur));
  return make(tr.id, end);
  function make(track: string, s: number) {
    const c = baseClip('text', track, s, dur); c.text = defaultText(text); c.label = 'Text';
    store.update((p) => p.clips.push(c)); store.select([c.id]); return c;
  }
}

const cloneClip = (c: Clip): Clip => {
  const n: Clip = JSON.parse(JSON.stringify(c)); n.id = uid(); n.effects.forEach((e) => (e.id = uid())); return n;
};

export function splitAt(t: number): number {
  const targets = store.sel.length ? store.p.clips.filter((c) => store.sel.includes(c.id)) : store.p.clips.filter((c) => t > c.start && t < c.start + c.dur);
  const valid = targets.filter((c) => t > c.start + 0.05 && t < c.start + c.dur - 0.05);
  if (!valid.length) return 0;
  const created: string[] = [];
  store.update((p) => {
    for (const c of valid) {
      const n = cloneClip(c);
      n.start = t; n.dur = c.start + c.dur - t; n.in = c.in + (t - c.start) * c.speed; n.fadeIn = 0;
      c.dur = t - c.start; c.fadeOut = 0;
      if (c.text) { c.text.animOut = { ...noAnim }; n.text!.animIn = { ...noAnim }; }
      p.clips.push(n); created.push(n.id);
    }
  });
  store.select(created);
  return valid.length;
}

export function deleteSelected() {
  if (!store.sel.length) return;
  const ids = new Set(store.sel);
  store.update((p) => (p.clips = p.clips.filter((c) => !ids.has(c.id))));
  store.sel = []; store.emit('select');
}

export function duplicateSelected() {
  const sel = store.p.clips.filter((c) => store.sel.includes(c.id)); if (!sel.length) return;
  const made: string[] = [];
  store.update((p) => {
    for (const c of sel) {
      const n = cloneClip(c), s = findFree(p, c.track, c.start + c.dur, c.dur);
      if (s === null) continue; n.start = s; p.clips.push(n); made.push(n.id);
    }
  });
  store.select(made);
}

/** Merge contiguous splits of the same media into one clip; otherwise butt clips end-to-end (join). */
export function combineSelected(): string {
  const sel = store.p.clips.filter((c) => store.sel.includes(c.id));
  if (sel.length < 2) return 'Select two or more clips (Shift+click) to combine.';
  const tr = sel[0].track;
  if (!sel.every((c) => c.track === tr)) return 'Combine works on clips from the same track.';
  sel.sort((a, b) => a.start - b.start);
  const contiguous = sel.every((c, i) => i === 0 || (c.type !== 'text' && c.mediaId === sel[0].mediaId && c.speed === sel[0].speed &&
    Math.abs(c.start - (sel[i - 1].start + sel[i - 1].dur)) < 0.06 && Math.abs(c.in - (sel[i - 1].in + sel[i - 1].dur * sel[i - 1].speed)) < 0.06));
  let msg = '';
  store.update((p) => {
    if (contiguous) {
      const first = p.clips.find((c) => c.id === sel[0].id)!, last = sel[sel.length - 1];
      first.dur = last.start + last.dur - first.start; first.fadeOut = last.fadeOut;
      const rm = new Set(sel.slice(1).map((c) => c.id)); p.clips = p.clips.filter((c) => !rm.has(c.id));
      msg = `Merged ${sel.length} clips into one.`;
    } else {
      let cursor = sel[0].start + sel[0].dur;
      for (let i = 1; i < sel.length; i++) { const c = p.clips.find((x) => x.id === sel[i].id)!; c.start = cursor; cursor += c.dur; }
      msg = `Joined ${sel.length} clips end-to-end.`;
    }
  });
  if (contiguous) store.select([sel[0].id]);
  return msg;
}

/** Change speed keeping the same source span; ripple following clips on that track. */
export function setSpeed(c: Clip, speed: number) {
  const span = c.dur * c.speed, newDur = span / speed, delta = newDur - c.dur, oldEnd = c.start + c.dur;
  c.speed = speed; c.dur = newDur;
  for (const o of store.p.clips) if (o !== c && o.track === c.track && o.start >= oldEnd - 1e-6) o.start = Math.max(0, o.start + delta);
}
