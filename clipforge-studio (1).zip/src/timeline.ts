import type { Clip } from './types';
import { findFree, projectDuration, store } from './store';
import { PEAKS_PER_SEC, runtime } from './media';
import { addMediaClip, addTextClip, combineSelected, deleteSelected, duplicateSelected, splitAt } from './clips';
import { fmtTime, h, toast } from './util';
import type { Player } from './player';

const KIND_OF: Record<string, string> = { video: 'video', image: 'video', text: 'text', audio: 'audio' };
const ICON: Record<string, string> = { video: '🎞', image: '🖼', text: 'T', audio: '♪' };

export class Timeline {
  pps = 80; snap = true;
  scroll!: HTMLElement; inner!: HTMLElement; head!: HTMLElement; labels!: HTMLElement; ruler!: HTMLElement;
  private els = new Map<string, HTMLElement>();
  constructor(public root: HTMLElement, private player: Player) {
    this.build();
    store.on((src) => {
      if (src === 'select') { this.paintSelection(); return; }
      if (src === 'drag') return;
      this.render();
    });
  }

  private build() {
    const mk = (label: string, act: () => void, id: string, title = '') => h('button', { class: 'btn sm', id, title, onclick: act }, label);
    const zoom = h('input', { type: 'range', min: 20, max: 300, value: this.pps, id: 'tl-zoom', title: 'Zoom', oninput: () => { this.pps = Number(zoom.value); this.render(); } });
    const snapCb = h('input', { type: 'checkbox', checked: this.snap, id: 'tl-snap', onchange: () => (this.snap = snapCb.checked) });
    const bar = h('div', { class: 'tl-toolbar' },
      mk('✂ Split', () => { const n = splitAt(this.player.t); if (!n) toast('Place the playhead inside a clip to split it.', 'info'); }, 'btn-split', 'Split at playhead (S)'),
      mk('🗑 Delete', deleteSelected, 'btn-delete', 'Delete (Del)'),
      mk('⧉ Duplicate', duplicateSelected, 'btn-dup'),
      mk('⛓ Combine', () => toast(combineSelected(), 'info'), 'btn-combine', 'Merge/join selected clips (Shift+click to multi-select)'),
      mk('＋ Text', () => addTextClip(this.player.t), 'btn-add-text'),
      h('label', { class: 'chk' }, snapCb, ' Snap'),
      h('span', { class: 'sp' }), h('span', { class: 'dim' }, '🔍'), zoom);
    this.labels = h('div', { class: 'tl-labels' });
    this.ruler = h('div', { class: 'tl-ruler' });
    this.inner = h('div', { class: 'tl-inner' });
    this.head = h('div', { class: 'playhead' }, h('div', { class: 'ph-knob' }));
    this.scroll = h('div', { class: 'tl-scroll', id: 'tl-scroll' }, this.inner);
    this.root.append(bar, h('div', { class: 'tl-body' }, this.labels, this.scroll));
    this.ruler.addEventListener('pointerdown', (e) => this.scrub(e));
    this.scroll.addEventListener('wheel', (e) => {
      if (!e.ctrlKey) return; e.preventDefault();
      this.pps = Math.min(300, Math.max(20, this.pps * (e.deltaY < 0 ? 1.15 : 0.87))); zoom.value = String(this.pps); this.render();
    }, { passive: false });
    this.render();
  }

  private scrub(e: PointerEvent) {
    const at = (ev: PointerEvent) => this.player.seek((ev.clientX - this.inner.getBoundingClientRect().left) / this.pps);
    at(e);
    const mv = (ev: PointerEvent) => at(ev), up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); };
    addEventListener('pointermove', mv); addEventListener('pointerup', up);
  }

  render() {
    const p = store.p, pps = this.pps;
    const total = Math.max(projectDuration(p) + 8, (this.scroll.clientWidth || 600) / pps);
    this.inner.style.width = `${total * pps}px`;
    this.inner.replaceChildren(); this.labels.replaceChildren(); this.els.clear();
    // ruler
    this.ruler.replaceChildren();
    const steps = [0.5, 1, 2, 5, 10, 30, 60, 120], step = steps.find((s) => s * pps >= 70) ?? 120;
    for (let t = 0; t <= total; t += step) {
      this.ruler.append(h('div', { class: 'tick', style: { left: `${t * pps}px` } }, h('span', {}, fmtTime(t, false).slice(0, 5))));
    }
    this.inner.append(this.ruler);
    this.labels.append(h('div', { class: 'tl-label ruler-spacer' }));
    for (const tr of p.tracks) {
      this.labels.append(h('div', { class: `tl-label k-${tr.kind}`, title: tr.id }, tr.name));
      const lane = h('div', { class: `tl-lane k-${tr.kind}`, 'data-track': tr.id });
      lane.addEventListener('pointerdown', (e) => { if (e.target === lane) store.select([]); });
      lane.addEventListener('dragover', (e) => { if (e.dataTransfer?.types.includes('text/clipforge-media')) { e.preventDefault(); lane.classList.add('drop'); } });
      lane.addEventListener('dragleave', () => lane.classList.remove('drop'));
      lane.addEventListener('drop', (e) => {
        e.preventDefault(); lane.classList.remove('drop');
        const id = e.dataTransfer?.getData('text/clipforge-media'); const m = p.media.find((x) => x.id === id); if (!m) return;
        const t = Math.max(0, (e.clientX - this.inner.getBoundingClientRect().left) / this.pps);
        addMediaClip(m, t, KIND_OF[m.kind] === tr.kind ? tr.id : undefined);
      });
      for (const c of p.clips.filter((x) => x.track === tr.id)) lane.append(this.clipEl(c));
      this.inner.append(lane);
    }
    // subtitle lane
    this.labels.append(h('div', { class: 'tl-label k-sub' }, 'Subtitles'));
    const sub = h('div', { class: 'tl-lane k-sub', 'data-track': 'SUB' });
    for (const cue of p.cues) {
      const el = h('div', { class: `cue ${store.selCue === cue.id ? 'sel' : ''}`, style: { left: `${cue.start * pps}px`, width: `${Math.max(4, (cue.end - cue.start) * pps)}px` }, title: cue.text, 'data-cue': cue.id }, cue.text.replace(/\n/g, ' '));
      el.addEventListener('pointerdown', (e) => { e.stopPropagation(); store.selCue = cue.id; store.sel = []; store.emit('select'); this.player.seek(cue.start); });
      sub.append(el);
    }
    this.inner.append(sub, this.head);
    this.paintSelection(); this.updatePlayhead();
  }

  private clipEl(c: Clip) {
    const el = h('div', { class: `clip t-${c.type}`, 'data-id': c.id },
      h('div', { class: 'h h-l' }), h('div', { class: 'h h-r' }));
    const name = c.type === 'text' ? c.text?.text.replace(/\n/g, ' ') ?? '' : c.label;
    if (c.type === 'audio' || c.type === 'video') {
      const cv = h('canvas', { class: 'wave' }); el.append(cv); this.drawWave(cv, c);
    }
    el.append(h('span', { class: 'cl-name' }, `${ICON[c.type]} ${name}${c.speed !== 1 ? ` ×${c.speed.toFixed(2)}` : ''}`));
    if (c.effects.length) el.append(h('span', { class: 'fxb', title: c.effects.map((e) => e.type).join(', ') }, 'fx'));
    el.addEventListener('pointerdown', (e) => this.startDrag(e, c, el));
    this.els.set(c.id, el); this.layout(el, c); return el;
  }
  private layout(el: HTMLElement, c: Clip) {
    el.style.left = `${c.start * this.pps}px`; el.style.width = `${Math.max(3, c.dur * this.pps)}px`;
  }
  private drawWave(cv: HTMLCanvasElement, c: Clip) {
    const peaks = c.mediaId ? runtime.get(c.mediaId)?.peaks : undefined; if (!peaks) return;
    const w = (cv.width = Math.min(3000, Math.max(1, Math.floor(c.dur * this.pps)))), hh = (cv.height = 32), x = cv.getContext('2d')!;
    x.fillStyle = c.type === 'audio' ? 'rgba(255,255,255,.55)' : 'rgba(255,255,255,.28)';
    for (let i = 0; i < w; i++) {
      const t0 = c.in + (i / w) * c.dur * c.speed, a = Math.min(1, (peaks[Math.floor(t0 * PEAKS_PER_SEC)] ?? 0) * c.volume * 1.2);
      x.fillRect(i, hh / 2 - (a * hh) / 2, 1, Math.max(1, a * hh));
    }
  }
  paintSelection() {
    for (const [id, el] of this.els) el.classList.toggle('sel', store.sel.includes(id));
    this.inner.querySelectorAll('.cue').forEach((e) => e.classList.toggle('sel', (e as HTMLElement).dataset.cue === store.selCue));
  }
  updatePlayhead() {
    const x = this.player.t * this.pps; this.head.style.left = `${x}px`;
    if (this.player.playing) {
      const s = this.scroll; if (x > s.scrollLeft + s.clientWidth - 40 || x < s.scrollLeft) s.scrollLeft = Math.max(0, x - 60);
    }
  }

  // ---------------- drag / trim / move ----------------
  private snapTo(val: number, exclude: string, edges: number[]): number {
    if (!this.snap) return val;
    const cands = [0, this.player.t];
    for (const o of store.p.clips) if (o.id !== exclude) cands.push(o.start, o.start + o.dur);
    const th = 8 / this.pps; let best = val, bd = th;
    for (const off of edges) for (const cnd of cands) { const d = Math.abs(val + off - cnd); if (d < bd) { bd = d; best = cnd - off; } }
    return best;
  }

  private startDrag(e: PointerEvent, c: Clip, el: HTMLElement) {
    if (e.button !== 0) return;
    e.preventDefault();
    const rect = el.getBoundingClientRect(), lx = e.clientX - rect.left;
    const mode = lx < 7 ? 'l' : lx > rect.width - 7 ? 'r' : 'move';
    if (e.shiftKey) store.select(store.sel.includes(c.id) ? store.sel.filter((i) => i !== c.id) : [...store.sel, c.id]);
    else if (!store.sel.includes(c.id)) store.select([c.id]);
    const o = { start: c.start, dur: c.dur, in: c.in, track: c.track }, x0 = e.clientX;
    const media = c.mediaId ? store.p.media.find((m) => m.id === c.mediaId) : undefined;
    const limited = (c.type === 'video' || c.type === 'audio') && media;
    const others = store.p.clips.filter((k) => k.track === c.track && k.id !== c.id);
    let moved = false;
    const mv = (ev: PointerEvent) => {
      const dx = ev.clientX - x0;
      if (!moved) { if (Math.abs(dx) < 3 && Math.abs(ev.clientY - e.clientY) < 6) return; moved = true; store.checkpoint(); }
      const dt = dx / this.pps;
      if (mode === 'move') {
        let ns = Math.max(0, o.start + dt); ns = Math.max(0, this.snapTo(ns, c.id, [0, o.dur]));
        let track = c.track;
        const lane = (document.elementsFromPoint(ev.clientX, ev.clientY).find((n) => (n as HTMLElement).classList?.contains('tl-lane')) as HTMLElement | undefined);
        if (lane && lane.dataset.track !== 'SUB') {
          const tr = store.track(lane.dataset.track!); if (tr.kind === KIND_OF[c.type]) { track = tr.id; if (lane !== el.parentElement) lane.append(el); }
        }
        const free = findFree(store.p, track, ns, c.dur, c.id);
        if (free !== null) { c.track = track; c.start = free; }
      } else if (mode === 'l') {
        const prevEnd = Math.max(0, ...others.filter((k) => k.start + k.dur <= o.start + 1e-6).map((k) => k.start + k.dur));
        let ns = this.snapTo(o.start + dt, c.id, [0]);
        const lo = Math.max(prevEnd, limited ? o.start - o.in / c.speed : 0), hi = o.start + o.dur - 0.1;
        ns = Math.min(hi, Math.max(lo, ns));
        const d = ns - o.start; c.start = ns; c.dur = o.dur - d; c.in = Math.max(0, o.in + d * c.speed);
      } else {
        const next = Math.min(Infinity, ...others.filter((k) => k.start >= o.start + o.dur - 1e-6).map((k) => k.start));
        let end = this.snapTo(o.start + o.dur + dt, c.id, [0]);
        const maxEnd = Math.min(next, limited ? o.start + (media!.duration - o.in) / c.speed : Infinity);
        end = Math.min(maxEnd, Math.max(o.start + 0.1, end)); c.dur = end - o.start;
      }
      this.layout(el, c);
      const cv = el.querySelector('canvas.wave') as HTMLCanvasElement | null; if (cv) this.drawWave(cv, c);
      store.emit('drag'); this.player.refresh();
    };
    const up = () => {
      removeEventListener('pointermove', mv); removeEventListener('pointerup', up);
      if (moved) { store.emit('ui'); }
    };
    addEventListener('pointermove', mv); addEventListener('pointerup', up);
  }
}
