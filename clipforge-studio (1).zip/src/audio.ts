import type { Project } from './types';
import { runtime } from './media';

/** Schedule every audible clip onto any (Offline)AudioContext. Used for BOTH preview and export mixing.
 *  `from` = timeline second at which playback starts; `base` = context time corresponding to `from`. */
export function scheduleAudio(ctx: BaseAudioContext, dest: AudioNode, p: Project, from: number, base: number): AudioScheduledSourceNode[] {
  const nodes: AudioScheduledSourceNode[] = [];
  for (const c of p.clips) {
    if ((c.type !== 'video' && c.type !== 'audio') || c.muted || !c.mediaId) continue;
    const buf = runtime.get(c.mediaId)?.buffer; if (!buf) continue;
    const cs = c.start, ce = c.start + c.dur; if (ce <= from) continue;
    const pf = Math.max(from, cs), T = (tl: number) => base + (tl - from);
    const gv = (tl: number) => Math.max(0, c.volume * Math.min(1, c.fadeIn > 0 ? (tl - cs) / c.fadeIn : 1, c.fadeOut > 0 ? (ce - tl) / c.fadeOut : 1));
    const src = ctx.createBufferSource(); src.buffer = buf; src.playbackRate.value = c.speed;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gv(pf), T(pf));
    if (c.fadeIn > 0 && cs + c.fadeIn > pf) g.gain.linearRampToValueAtTime(c.volume, T(cs + c.fadeIn));
    if (c.fadeOut > 0) {
      const fs = Math.max(ce - c.fadeOut, pf, c.fadeIn > 0 ? cs + c.fadeIn : pf);
      if (fs < ce) { g.gain.setValueAtTime(gv(fs), T(fs)); g.gain.linearRampToValueAtTime(0, T(ce)); }
    }
    const offset = c.in + (pf - cs) * c.speed, span = (ce - pf) * c.speed;
    if (offset >= buf.duration) continue;
    src.connect(g).connect(dest);
    src.start(T(pf), offset, Math.min(span, buf.duration - offset));
    nodes.push(src);
  }
  return nodes;
}

export async function mixToWav(p: Project, duration: number, sampleRate = 44100): Promise<Blob> {
  const len = Math.max(1, Math.ceil(duration * sampleRate));
  const oc = new OfflineAudioContext(2, len, sampleRate);
  scheduleAudio(oc, oc.destination, p, 0, 0);
  return encodeWav(await oc.startRendering());
}
export function encodeWav(buf: AudioBuffer): Blob {
  const ch = buf.numberOfChannels, n = buf.length, out = new DataView(new ArrayBuffer(44 + n * ch * 2));
  const w = (o: number, s: string) => [...s].forEach((c, i) => out.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); out.setUint32(4, 36 + n * ch * 2, true); w(8, 'WAVEfmt '); out.setUint32(16, 16, true); out.setUint16(20, 1, true);
  out.setUint16(22, ch, true); out.setUint32(24, buf.sampleRate, true); out.setUint32(28, buf.sampleRate * ch * 2, true);
  out.setUint16(32, ch * 2, true); out.setUint16(34, 16, true); w(36, 'data'); out.setUint32(40, n * ch * 2, true);
  const chans = Array.from({ length: ch }, (_, i) => buf.getChannelData(i));
  let o = 44;
  for (let i = 0; i < n; i++) for (let c = 0; c < ch; c++) { const v = Math.max(-1, Math.min(1, chans[c][i])); out.setInt16(o, v < 0 ? v * 0x8000 : v * 0x7fff, true); o += 2; }
  return new Blob([out.buffer], { type: 'audio/wav' });
}
