import type { Cue } from './types';
import { uid } from './util';

const tc = (s: string) => {
  const m = s.trim().match(/^(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})$/) || s.trim().match(/^(\d{1,2}):(\d{1,2})[,.](\d{1,3})$/);
  if (!m) return NaN;
  const a = m.slice(1).map(Number);
  return a.length === 4 ? a[0] * 3600 + a[1] * 60 + a[2] + a[3] / Math.pow(10, String(m[4]).length) : a[0] * 60 + a[1] + a[2] / Math.pow(10, String(m[3]).length);
};
export function parseSRT(text: string): Cue[] {
  const cues: Cue[] = [];
  for (const block of text.replace(/^﻿/, '').replace(/\r/g, '').split(/\n{2,}/)) {
    const lines = block.split('\n').filter((l) => l.trim() !== '' || false);
    const ti = lines.findIndex((l) => l.includes('-->')); if (ti < 0) continue;
    const [a, b] = lines[ti].split('-->'); const s = tc(a), e = tc((b || '').trim().split(/\s+/)[0]);
    if (isNaN(s) || isNaN(e) || e <= s) continue;
    const body = lines.slice(ti + 1).join('\n').replace(/<[^>]+>/g, '').trim();
    if (body) cues.push({ id: uid(), start: s, end: e, text: body });
  }
  return cues.sort((x, y) => x.start - y.start);
}
const pad = (n: number, w = 2) => String(n).padStart(w, '0');
export const srtTime = (t: number) => {
  const ms = Math.round(t * 1000), h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60;
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms % 1000, 3)}`;
};
export function serializeSRT(cues: Cue[]): string {
  return [...cues].sort((a, b) => a.start - b.start).map((c, i) => `${i + 1}\n${srtTime(c.start)} --> ${srtTime(c.end)}\n${c.text}\n`).join('\n');
}
