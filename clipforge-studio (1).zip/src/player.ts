import type { Clip } from './types';
import { canvasSize, projectDuration, store } from './store';
import { audioCtx, runtime } from './media';
import { scheduleAudio } from './audio';
import { clipActive, renderFrame } from './render/frame';
import { ensureFont } from './fonts';

type Cb = () => void;

export class Player {
  canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D;
  t = 0; playing = false;
  private vids = new Map<string, HTMLVideoElement>();
  private startWall = 0; private startT = 0; private raf = 0; private pending = false;
  private nodes: AudioScheduledSourceNode[] = [];
  private master: GainNode | null = null;
  onTick: Cb = () => {};
  frames = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas; this.ctx = canvas.getContext('2d')!;
    this.resize();
  }
  get duration() { return projectDuration(store.p); }

  resize() {
    const [w, h] = canvasSize(store.p.aspect, 720);
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
  }

  private videoFor(c: Clip) {
    let v = this.vids.get(c.id);
    const m = c.mediaId ? runtime.get(c.mediaId) : undefined; if (!m) return null;
    if (!v) {
      v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto';
      v.addEventListener('seeked', () => this.requestRender());
      v.addEventListener('loadeddata', () => this.requestRender());
      v.src = m.url; this.vids.set(c.id, v);
    } else if (v.src !== m.url) v.src = m.url;
    return v;
  }
  private getSrc = (c: Clip): CanvasImageSource | null => {
    if (c.type === 'image') return (c.mediaId && runtime.get(c.mediaId)?.img) || null;
    if (c.type !== 'video') return null;
    const v = this.videoFor(c);
    return v && v.readyState >= 2 ? v : null;
  };

  /** Position/play the underlying <video> elements for time t. */
  private syncVideos() {
    const live = new Set<string>();
    for (const c of store.p.clips) {
      if (c.type !== 'video') continue;
      live.add(c.id);
      const active = clipActive(c, this.t);
      const v = this.videoFor(c); if (!v) continue;
      if (!active) { if (!v.paused) v.pause(); continue; }
      const want = Math.min(c.in + (this.t - c.start) * c.speed, Math.max(0, (v.duration || 1e9) - 0.001));
      if (this.playing) {
        if (v.playbackRate !== c.speed) v.playbackRate = Math.min(16, Math.max(0.0625, c.speed));
        if (Math.abs(v.currentTime - want) > 0.3) v.currentTime = want;
        if (v.paused) v.play().catch(() => {});
      } else {
        if (!v.paused) v.pause();
        if (Math.abs(v.currentTime - want) > 0.004) v.currentTime = want;
      }
    }
    for (const [id, v] of this.vids) if (!live.has(id)) { v.pause(); v.removeAttribute('src'); v.load(); this.vids.delete(id); }
  }

  draw() {
    this.resize(); this.syncVideos();
    renderFrame(this.ctx, store.p, this.t, this.getSrc); this.frames++;
  }
  requestRender() {
    if (this.playing || this.pending) return;
    this.pending = true; requestAnimationFrame(() => { this.pending = false; this.draw(); });
  }
  /** Re-render after fonts for text clips finish loading. */
  async fontsThenRender() {
    await Promise.all(store.p.clips.filter((c) => c.text).map((c) => ensureFont(c.text!.font, c.text!.bold, c.text!.text)));
    await ensureFont(store.p.subStyle.font, store.p.subStyle.bold, store.p.cues.map((c) => c.text).join(''));
    this.requestRender();
  }

  seek(t: number) {
    const was = this.playing; if (was) this.stopAudio();
    this.t = Math.max(0, Math.min(t, Math.max(this.duration, 0)));
    if (was) { this.startWall = performance.now(); this.startT = this.t; this.startAudio(); }
    this.requestRender(); this.onTick();
  }
  private startAudio() {
    const ac = audioCtx(); if (ac.state === 'suspended') ac.resume();
    this.master = ac.createGain(); this.master.connect(ac.destination);
    this.nodes = scheduleAudio(ac, this.master, store.p, this.t, ac.currentTime + 0.06);
  }
  private stopAudio() {
    for (const n of this.nodes) { try { n.stop(); } catch { /* */ } n.disconnect(); }
    this.nodes = []; this.master?.disconnect(); this.master = null;
  }
  play() {
    if (this.playing) return;
    if (this.t >= this.duration - 0.01) this.t = 0;
    if (this.duration <= 0) return;
    this.playing = true; this.startWall = performance.now(); this.startT = this.t; this.startAudio();
    const loop = () => {
      if (!this.playing) return;
      this.t = this.startT + (performance.now() - this.startWall) / 1000;
      if (this.t >= this.duration) { this.t = this.duration; this.pause(); this.draw(); this.onTick(); return; }
      this.draw(); this.onTick(); this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop); this.onTick();
  }
  pause() {
    if (!this.playing) return;
    this.playing = false; cancelAnimationFrame(this.raf); this.stopAudio();
    for (const v of this.vids.values()) v.pause();
    this.requestRender(); this.onTick();
  }
  toggle() { this.playing ? this.pause() : this.play(); }
  /** Called when the project changed while playing: restart audio scheduling at the current time. */
  refresh() {
    if (this.playing) { this.stopAudio(); this.startT = this.t; this.startWall = performance.now(); this.startAudio(); }
    else this.requestRender();
  }
}
