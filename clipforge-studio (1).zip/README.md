# CLIPFORGE STUDIO

Browser video editor (Vite + TypeScript): timeline, Thai/English text, effects, audio, subtitles, MP4 export (FFmpeg.wasm).

## Run locally
    npm install
    npm run dev          # http://localhost:5173
    npm run build && npm run preview

## Deploy (Vercel)
Framework: Vite · Install: `npm install` · Build: `npm run build` · Output: `dist`.
`vercel.json` already sets these plus COOP/COEP headers and long-term caching.
The FFmpeg core (~32 MB) is copied from node_modules into `public/ffmpeg/` by `npm run prepare-ffmpeg`, which runs automatically before dev/build (that folder is git-ignored).

## Notes
- Everything runs client-side; there is no backend, no API keys and no environment variables.
- Projects and media are stored in the visitor's own browser (IndexedDB).
- Exports are held in browser memory: keep to a few minutes at 720p/30.
