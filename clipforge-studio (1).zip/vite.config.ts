import { defineConfig } from 'vite';

// COOP/COEP are only required for the multi-threaded ffmpeg core (@ffmpeg/core-mt).
// The default single-thread core used here works without them, but we send them
// anyway so switching to core-mt later is a one-line change.
const isolation = {
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Embedder-Policy': 'require-corp',
};

export default defineConfig({
  optimizeDeps: { exclude: ['@ffmpeg/ffmpeg', '@ffmpeg/util'] },
  worker: { format: 'es' },
  server: { headers: isolation, host: '0.0.0.0' },
  preview: { headers: isolation, host: '0.0.0.0' },
  build: { target: 'es2022' },
});
